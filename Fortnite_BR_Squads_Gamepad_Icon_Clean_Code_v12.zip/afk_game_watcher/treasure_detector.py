                                                                             

                                                                          
                                                                             
                                                     
   
from pathlib import Path

import cv2
import numpy as np


REFERENCE_SIZE = (1920, 1080)


class TreasureDetector:
    def __init__(self, templates_dir):
        folder = Path(templates_dir)
        self.title = cv2.imread(str(folder / 'treasure_title_mask.png'), cv2.IMREAD_GRAYSCALE)
        self.claim = cv2.imread(str(folder / 'treasure_claim_mask.png'), cv2.IMREAD_GRAYSCALE)
        if self.title is None or self.claim is None:
            raise FileNotFoundError('The bundled treasure_title_mask.png and treasure_claim_mask.png are required.')

    @staticmethod
    def _best(mask, template, box, scales):
        h, w = mask.shape[:2]
        x0, y0, x1, y1 = (round(v * (w if i % 2 == 0 else h))
                          for i, v in enumerate(box))
        region = mask[y0:y1, x0:x1]
        if region.size == 0:
            return 0., None
        high_score, high_center = 0., None
        for scale in scales:
            tw, th = round(template.shape[1] * scale), round(template.shape[0] * scale)
            if min(tw, th) < 12 or th > region.shape[0] or tw > region.shape[1]:
                continue
            sample = (template if scale == 1. else
                      cv2.resize(template, (tw, th), interpolation=cv2.INTER_NEAREST))
            _, score, _, corner = cv2.minMaxLoc(cv2.matchTemplate(region, sample, cv2.TM_CCOEFF_NORMED))
            if score > high_score:
                high_score = float(score)
                high_center = (x0 + corner[0] + tw // 2, y0 + corner[1] + th // 2)
        return high_score, high_center

    def detect(self, rgb):
                                                                                         

                                                                              
                                                                         
           
        h, w = rgb.shape[:2]
        if (w, h) != REFERENCE_SIZE:
            rgb = cv2.resize(rgb, REFERENCE_SIZE, interpolation=cv2.INTER_AREA)
                                                                
        title_mask = (np.min(rgb, axis=2) > 220).astype(np.uint8) * 255
        title_score, _ = self._best(title_mask, self.title,
                                    (.025, .205, .47, .40), (.8, .9, 1., 1.1, 1.2))
        if title_score < .73:
            return False, None, title_score, 0.
                                                                              
        claim_mask = (np.max(rgb, axis=2) < 105).astype(np.uint8) * 255
        claim_score, target = self._best(claim_mask, self.claim,
                                         (.30, .76, .70, .995), (.8, .9, 1., 1.1, 1.2))
        if target is not None:
            target = (round(target[0] * w / 1920), round(target[1] * h / 1080))
                                                                           
                                                                          
        return (claim_score >= .75 and target is not None), target, title_score, claim_score
