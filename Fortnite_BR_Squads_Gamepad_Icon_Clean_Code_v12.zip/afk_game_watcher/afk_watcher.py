import ctypes
import json
import queue
import re
import random
import threading
import urllib.request
import urllib.error
from urllib.parse import urlparse
import time
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, ttk

import cv2
import numpy as np
import pyautogui
import pydirectinput
from mode_selector import ModeMenuRecognizer
from treasure_detector import TreasureDetector

try:
    import keyboard
except ImportError:
    keyboard = None

BASE = Path(__file__).resolve().parent
APP_ICON_PNG = BASE / 'watcher_icon.png'
APP_ICON_ICO = BASE / 'watcher.ico'
TEMPLATE_DIR = BASE / 'templates'
TEMPLATE_DIR.mkdir(exist_ok=True)
CONFIG = BASE / 'config.json'
LABELS = {
    'return': 'Post-elimination RETURN TO LOBBY button',
    'ready': 'Solo lobby PLAY button',
    'party_ready': 'Party lobby READY button (when teammates have joined)',
    'hud': 'ALIVE in-game HUD (capture a distinctive alive-only indicator)',
    'knocked': 'DBNO / knocked-down indicator (Squads, optional)',
    'spectate': 'SPECTATING teammate indicator (Squads, optional)',
    'queue': 'Matchmaking / queue indicator (optional)',
    'loading': 'Loading screen indicator (optional)',
    'pirate': 'PIRATE SHOP ACCESS banner (optional: capture from game)',
    'glide': 'SPACE TO DEPLOY prompt (hold W only until text disappears)',
    'survey_skip': 'Fortnite feedback survey SKIP button (optional)',
    'mode_custom': 'Custom game menu CUSTOM KEY button',
    'mode_lobby': 'Custom game menu GO TO LOBBY button',
    'starter': 'Battle Royale starter screen title (not the Play button)',
    'mode_picker': 'OPTIONAL fallback: lobby mode selector box (Solo/Duos/Trios/Squad - any mode)',
    'mode_close': 'OPTIONAL: CLOSE button at bottom of the Battle Royale options panel',
}
STAGES = {
    'return': 'ELIMINATED / RETURNING TO LOBBY',
    'ready': 'FORTNITE LOBBY / READYING UP',
    'hud': 'FORTNITE SQUADS / ALIVE / MOVING',
    'glide': 'SPACE TO DEPLOY VISIBLE / HOLDING W',
    'landing': 'GLIDE FINISHED / SPRINTING IMMEDIATELY',
    'survey_skip': 'SURVEY DETECTED / SKIPPING',
    'storm': 'IN STORM / CONTINUING MOVEMENT',
    'reboot': 'REBOOT ASSUMED / MOVING SIDEWAYS (10S)',
    'knocked': 'KNOCKED DOWN / CRAWLING',
    'spectate': 'ELIMINATED / SPECTATING SQUAD',
    'queue': 'FORTNITE MATCHMAKING / QUEUEING',
    'loading': 'LOADING INTO FORTNITE MATCH',
    'unknown': 'WAITING / UNKNOWN SCREEN',
    'menu_scroll': 'CUSTOM GAME MENU / SCROLLING UP',
    'starter_wait': 'WAITING FOR STARTER SCREEN / PLAY',
    'mode_check': 'CHECKING BATTLE ROYALE SQUAD FILL',
    'mode_fix': 'SETTING BATTLE ROYALE SQUAD FILL',
    'treasure': 'TREASURE FOUND / CLAIMING ALL',
}


pyautogui.FAILSAFE = True
pydirectinput.PAUSE = 0.02


def foreground_title():
    handle = ctypes.windll.user32.GetForegroundWindow()
    length = ctypes.windll.user32.GetWindowTextLengthW(handle)
    buf = ctypes.create_unicode_buffer(length + 1)
    ctypes.windll.user32.GetWindowTextW(handle, buf, len(buf))
    return buf.value


def release_movement():
    for k in ('w', 'a', 's', 'd', 'space', 'u', 'ctrlleft'):
        try:
            pydirectinput.keyUp(k)
        except Exception:
            pass


def send_camera_turn(degrees, units_per_90, window_hint, stop_event=None):
                                                                          

                                                                          
                                                                            
                                                                          
                                                                          
       
    distance = round(float(units_per_90) * abs(degrees) / 90.0)
    distance *= -1 if degrees < 0 else 1
    steps = max(16, min(40, (abs(distance) + 239) // 240))
    for step in range(steps):
        if ((stop_event is not None and stop_event.is_set())
                or window_hint not in foreground_title().lower()):
            return False
        delta = round((step + 1) * distance / steps) - round(step * distance / steps)
        if delta:
                                                                       
                                                                          
            pydirectinput.moveRel(int(delta), 0, relative=True, _pause=False)
        if stop_event is not None:
            if stop_event.wait(0.006):
                return False
        else:
            time.sleep(0.006)
    return True




def movement_profile(stage, now, reboot_until, reboot_side, hold_min, hold_max, rng=random):
                                                                                  

                                                                                
                                                                               
                                                                           
       
    if stage == 'reboot':
        if reboot_side not in ('a', 'd') or reboot_until <= now:
            return (), 0.0, False
        return (reboot_side,), min(10.0, max(0.0, reboot_until - now)), False
    if stage == 'knocked':
        return (rng.choice(('w', 'w', 'a', 's', 'd')),), rng.uniform(5.0, 8.0), False
    if stage == 'unknown':
        return (rng.choice(('w', 'a', 's', 'd')),), rng.uniform(1.8, 2.6), False
    if stage == 'landing':
        return ('w',), min(rng.uniform(hold_min, hold_max), max(0.2, reboot_until - now)), True
    return (rng.choice([('w',)] * 8 + [('w', 'a')] * 2 + [('w', 'd')] * 2 +
                       [('s',), ('a',), ('d',)])), rng.uniform(hold_min, hold_max), True


class WatcherApp:
    def __init__(self, root):
        self.root = root
        if APP_ICON_PNG.is_file():
            try:
                self._app_icon = tk.PhotoImage(file=str(APP_ICON_PNG))
                self.root.iconphoto(True, self._app_icon)
            except tk.TclError:
                pass
        if APP_ICON_ICO.is_file():
            try:
                self.root.iconbitmap(default=str(APP_ICON_ICO))
            except tk.TclError:
                pass
        self.root.title('Fortnite AFK Game Watcher')
        self.root.geometry('750x780')
        self.root.resizable(False, False)
        self.stop_event = threading.Event()
        self.thread = None
        self._camera_test_pending = False
        self._camera_test_stop = threading.Event()
        self.events = queue.Queue()
        self.last_action = tk.StringVar(value='Not started')
        self.stage = tk.StringVar(value='STOPPED')
        self.match_info = tk.StringVar(value='No screenshots checked yet')
        self.window_text = tk.StringVar(value='Fortnite')
        self.threshold = tk.DoubleVar(value=0.86)
        self.move_enabled = tk.BooleanVar(value=True)
        self.preferred_build = tk.StringVar(value='Zero Build')
        self.click_enabled = tk.BooleanVar(value=False)
        self.hold_min = tk.DoubleVar(value=25.0)
        self.hold_max = tk.DoubleVar(value=45.0)
        self.turn_90_pixels = tk.IntVar(value=4800)
        self.emotes_enabled = tk.BooleanVar(value=True)
        self.emote_min = tk.DoubleVar(value=50.0)
        self.emote_max = tk.DoubleVar(value=100.0)
        self.click_min = tk.DoubleVar(value=3.0)
        self.click_max = tk.DoubleVar(value=7.0)
        self.templates = {}
        self.mode_templates = {}
        self.mode_menu = ModeMenuRecognizer(TEMPLATE_DIR)
        self.treasure_detector = TreasureDetector(TEMPLATE_DIR)
        for mode_name in ('mode_zero_squad', 'mode_zero_solo', 'mode_build_squad'):
            mode_path = TEMPLATE_DIR / f'{mode_name}.png'
            self.mode_templates[mode_name] = cv2.imread(str(mode_path), cv2.IMREAD_GRAYSCALE) if mode_path.exists() else None
        self.pirate_samples = []
        self.webhook_url = tk.StringVar(value='')
        self.discord_user_id = tk.StringVar(value='')
        self.notify_stuck = tk.BooleanVar(value=True)
        self._unknown_since = None
        self._unknown_notified = False
        self.stuck_status = tk.StringVar(value='Unknown-screen timer: inactive')
        self.webhook_enabled = tk.BooleanVar(value=True)
        self.notify_game = tk.BooleanVar(value=True)
        self.notify_pirate = tk.BooleanVar(value=True)
        self.notify_stages = tk.BooleanVar(value=True)
        self.notify_actions = tk.BooleanVar(value=True)
        self.action_interval = tk.IntVar(value=30)
        self._last_notified_stage = None
        self._last_stage_sent = {}
        self._last_action_sent = {}
        self._action_counts = {}
        self._action_flush_at = time.monotonic()
        self.pirate_confidence = tk.DoubleVar(value=0.72)
        self.webhook_status = tk.StringVar(value='Webhook not tested')
        self.webhook_queue = queue.Queue(maxsize=500)
        self.webhook_worker = threading.Thread(target=self._webhook_sender, daemon=True)
        self.webhook_worker.start()
        self.capture_status = {}
        self._build_ui()
        self._load_config()
        self._load_templates()
        self._register_hotkeys()
        self.root.after(100, self._drain)
        self.root.protocol('WM_DELETE_WINDOW', self.close)

    def _build_ui(self):
        canvas = tk.Canvas(self.root, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.root, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)
        frame = ttk.Frame(canvas, padding=15)
        container_id = canvas.create_window((0, 0), window=frame, anchor='nw')
        frame.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>', lambda e: canvas.itemconfigure(container_id, width=e.width))
        canvas.bind('<MouseWheel>', lambda e: canvas.yview_scroll(-int(e.delta / 120), 'units'))
        ttk.Label(frame, text='FORTNITE AFK GAME WATCHER', font=('Segoe UI', 16, 'bold')).pack(anchor='w')
        ttk.Label(frame, text='Battle Royale Squads: alive / knocked / spectating / lobby / matchmaking').pack(anchor='w', pady=(0, 14))
        self.stage_label = ttk.Label(frame, textvariable=self.stage, font=('Segoe UI', 15, 'bold'))
        self.stage_label.pack(anchor='w')
        ttk.Label(frame, textvariable=self.match_info, wraplength=540).pack(anchor='w', pady=3)
        ttk.Label(frame, textvariable=self.last_action, wraplength=540).pack(anchor='w', pady=(0, 14))
        row = ttk.Frame(frame)
        row.pack(fill='x', pady=3)
        ttk.Label(row, text='Fortnite window title contains:').pack(side='left')
        ttk.Entry(row, textvariable=self.window_text, width=34).pack(side='left', padx=8)
        row2 = ttk.Frame(frame)
        row2.pack(fill='x', pady=8)
        ttk.Label(row2, text='Match confidence:').pack(side='left')
        ttk.Spinbox(row2, from_=0.75, to=0.99, increment=0.01, textvariable=self.threshold, width=7).pack(side='left', padx=8)
        ttk.Checkbutton(row2, text='WASD + Left Ctrl sprint + jump + camera', variable=self.move_enabled).pack(side='left', padx=8)
        preset_row = ttk.Frame(frame)
        preset_row.pack(fill='x', pady=(3, 6))
        ttk.Label(preset_row, text='Auto-correct BUILD / ZERO BUILD + Unranked + Squad + Fill; preferred:').pack(side='left')
        ttk.Combobox(preset_row, textvariable=self.preferred_build, values=('Zero Build', 'Build'), state='readonly', width=13).pack(side='left', padx=6)
        controls = ttk.LabelFrame(frame, text='In-game movement (alive, knocked, unknown recovery or reboot)', padding=8)
        controls.pack(fill='x', pady=5)
        durations = ttk.Frame(controls)
        durations.pack(fill='x')
        ttk.Label(durations, text='Hold WASD for (seconds):').pack(side='left')
        ttk.Spinbox(durations, from_=0.2, to=120, increment=1, textvariable=self.hold_min, width=6).pack(side='left', padx=5)
        ttk.Label(durations, text='to').pack(side='left')
        ttk.Spinbox(durations, from_=0.2, to=120, increment=1, textvariable=self.hold_max, width=6).pack(side='left', padx=5)
        turns = ttk.Frame(controls)
        turns.pack(fill='x', pady=(6, 0))
        ttk.Label(turns, text='90° turn strength (relative mouse units):').pack(side='left')
        ttk.Spinbox(turns, from_=200, to=30000, increment=400, textvariable=self.turn_90_pixels, width=8).pack(side='left', padx=6)
        ttk.Button(turns, text='Test 90°', command=self._test_camera_turn).pack(side='left', padx=6)
        ttk.Label(controls, text='Press Test 90°, switch to Fortnite within 3 seconds, and compare the turn. Lower if it overshoots; raise if too small.').pack(anchor='w', pady=(3, 0))
        emotes = ttk.Frame(controls)
        emotes.pack(fill='x', pady=(6, 0))
        ttk.Checkbutton(emotes, text='Random emotes (hold U, then 1–8)', variable=self.emotes_enabled).pack(side='left')
        ttk.Label(emotes, text='Every').pack(side='left', padx=(14, 4))
        ttk.Spinbox(emotes, from_=15, to=600, increment=5, textvariable=self.emote_min, width=5).pack(side='left')
        ttk.Label(emotes, text='to').pack(side='left', padx=4)
        ttk.Spinbox(emotes, from_=15, to=600, increment=5, textvariable=self.emote_max, width=5).pack(side='left')
        ttk.Label(emotes, text='sec (no movement during emote)').pack(side='left', padx=4)
        clicks = ttk.Frame(controls)
        clicks.pack(fill='x', pady=(6, 0))
        ttk.Checkbutton(clicks, text='Left-click periodically (attack/use)', variable=self.click_enabled).pack(side='left')
        ttk.Label(clicks, text='Every').pack(side='left', padx=(15, 4))
        ttk.Spinbox(clicks, from_=0.5, to=60, increment=0.5, textvariable=self.click_min, width=6).pack(side='left')
        ttk.Label(clicks, text='to').pack(side='left', padx=4)
        ttk.Spinbox(clicks, from_=0.5, to=60, increment=0.5, textvariable=self.click_max, width=6).pack(side='left')
        ttk.Label(clicks, text='sec').pack(side='left', padx=4)
        webhook_box = ttk.LabelFrame(frame, text='Discord webhook notifications', padding=7)
        webhook_box.pack(fill='x', pady=(8, 3))
        urlrow = ttk.Frame(webhook_box)
        urlrow.pack(fill='x')
        ttk.Label(urlrow, text='Webhook URL:').pack(side='left')
        ttk.Entry(urlrow, textvariable=self.webhook_url, show='*', width=60).pack(side='left', fill='x', expand=True, padx=5)
        ttk.Button(urlrow, text='Test', command=self.test_webhook).pack(side='right')
        ping_row = ttk.Frame(webhook_box)
        ping_row.pack(fill='x', pady=(5, 1))
        ttk.Label(ping_row, text='Discord User ID:').pack(side='left')
        ttk.Entry(ping_row, textvariable=self.discord_user_id, width=25).pack(side='left', padx=5)
        ttk.Checkbutton(ping_row, text='Ping after 20 minutes on an unknown screen', variable=self.notify_stuck).pack(side='left', padx=8)
        ttk.Label(webhook_box, textvariable=self.stuck_status).pack(anchor='w', pady=(2, 4))
        opts = ttk.Frame(webhook_box)
        opts.pack(fill='x', pady=(4,0))
        ttk.Checkbutton(opts, text='Enable', variable=self.webhook_enabled).pack(side='left')
        ttk.Checkbutton(opts, text='Notify when returning to lobby', variable=self.notify_game).pack(side='left', padx=8)
        ttk.Checkbutton(opts, text='Notify Pirate Shop Access', variable=self.notify_pirate).pack(side='left')
        extra = ttk.Frame(webhook_box)
        extra.pack(fill='x', pady=(5, 0))
        ttk.Checkbutton(extra, text='Notify game stage changes', variable=self.notify_stages).pack(side='left')
        ttk.Checkbutton(extra, text='Notify all actions (batched)', variable=self.notify_actions).pack(side='left', padx=10)
        ttk.Label(extra, text='Summary every').pack(side='left')
        ttk.Spinbox(extra, from_=15, to=300, increment=15, textvariable=self.action_interval, width=5).pack(side='left', padx=4)
        ttk.Label(extra, text='sec').pack(side='left')
        confidence = ttk.Frame(webhook_box)
        confidence.pack(fill='x')
        ttk.Label(confidence, text='Pirate template match:').pack(side='left')
        ttk.Spinbox(confidence, from_=0.60, to=0.99, increment=0.01, textvariable=self.pirate_confidence, width=6).pack(side='left', padx=6)
        ttk.Label(confidence, textvariable=self.webhook_status).pack(side='left', padx=12)
        ttk.Separator(frame).pack(fill='x', pady=8)
        ttk.Label(frame, text='1. CAPTURE SCREEN REGIONS (game should be visible)', font=('Segoe UI', 10, 'bold')).pack(anchor='w', pady=3)
        for key, label in LABELS.items():
            line = ttk.Frame(frame)
            line.pack(fill='x', pady=2)
            ttk.Button(line, text='Capture', width=12, command=lambda k=key: self.capture(k)).pack(side='left')
            ttk.Label(line, text=label).pack(side='left', padx=10)
            status = ttk.Label(line, text='NOT SAVED', foreground='#a33')
            status.pack(side='right', padx=4)
            self.capture_status[key] = status
        ttk.Separator(frame).pack(fill='x', pady=12)
        ttk.Label(frame, text='2. START / STOP', font=('Segoe UI', 10, 'bold')).pack(anchor='w', pady=3)
        actions = ttk.Frame(frame)
        actions.pack(fill='x', pady=6)
        ttk.Button(actions, text='Start (F6)', command=self.start).pack(side='left', padx=(0, 8))
        ttk.Button(actions, text='Stop (F7)', command=self.stop).pack(side='left', padx=(0, 8))
        ttk.Button(actions, text='EMERGENCY STOP (F8)', command=self.emergency).pack(side='left')
        ttk.Label(frame, text='Return > Ready > Knocked > Spectating > Queue/Loading > Alive HUD.\nKnocked: crawl; unknown after gameplay: short WASD; suspected reboot: A or D for 10s. Return to Lobby interrupts.', wraplength=535).pack(anchor='w', pady=9)
        self.log = tk.Text(frame, height=4, state='disabled', font=('Consolas', 9))
        self.log.pack(fill='both', expand=True)

    def _register_hotkeys(self):
        if keyboard is None:
            self._log('Global hotkey module unavailable. Use the buttons.')
            return
        try:
            keyboard.add_hotkey('f6', lambda: self.events.put(('cmd', 'start')))
            keyboard.add_hotkey('f7', lambda: self.events.put(('cmd', 'stop')))
            keyboard.add_hotkey('f8', lambda: self.events.put(('cmd', 'emergency')))
        except Exception as exc:
            self._log(f'Hotkeys unavailable: {exc}. Use GUI controls.')

    def _log(self, msg):
        self.log.configure(state='normal')
        self.log.insert('end', f'{time.strftime("%H:%M:%S")}  {msg}\n')
        self.log.see('end')
        self.log.configure(state='disabled')

    def _load_config(self):
        if CONFIG.exists():
            try:
                data = json.loads(CONFIG.read_text('utf-8'))
                self.window_text.set(data.get('window_title', 'Fortnite'))
                self.threshold.set(data.get('threshold', .86))
                self.move_enabled.set(data.get('movement', True))
                self.preferred_build.set(data.get('preferred_build', 'Zero Build'))
                self.click_enabled.set(data.get('click_enabled', False))
                self.webhook_url.set(data.get('webhook_url', ''))
                self.discord_user_id.set(str(data.get('discord_user_id', '')))
                self.notify_stuck.set(data.get('notify_stuck', True))
                self.webhook_enabled.set(data.get('webhook_enabled', True))
                self.notify_game.set(data.get('notify_game', True))
                self.notify_pirate.set(data.get('notify_pirate', True))
                self.notify_stages.set(data.get('notify_stages', True))
                self.notify_actions.set(data.get('notify_actions', True))
                self.action_interval.set(data.get('action_interval', 30))
                self.pirate_confidence.set(data.get('pirate_confidence', 0.72))
                for name, default in [('hold_min', 25.), ('hold_max', 45.), ('click_min', 3.), ('click_max', 7.),
                                      ('emote_min', 50.), ('emote_max', 100.)]:
                    getattr(self, name).set(data.get(name, default))
                                                                                           
                if data.get('hold_min') == 2.0 and data.get('hold_max') == 4.0 and not data.get('movement_v2'):
                    self.hold_min.set(25.0)
                    self.hold_max.set(45.0)
                                                                          
                                                                          
                                                              
                old_units = int(data.get('turn_90_pixels', 480))
                if not data.get('camera_turn_v5', False):
                    old_units = max(4800, min(12000, old_units * 10))
                self.turn_90_pixels.set(old_units)
                self.emotes_enabled.set(data.get('emotes_enabled', True))
            except (OSError, ValueError) as exc:
                self._log(f'Config loading error: {exc}')

    def _save_config(self):
        CONFIG.write_text(json.dumps({
            'window_title': self.window_text.get().strip(), 'threshold': self.threshold.get(),
            'movement': self.move_enabled.get(), 'click_enabled': self.click_enabled.get(),
            'preferred_build': self.preferred_build.get(),
            'hold_min': self.hold_min.get(), 'hold_max': self.hold_max.get(),
            'movement_v2': True, 'turn_90_pixels': self.turn_90_pixels.get(), 'camera_turn_v5': True,
            'emotes_enabled': self.emotes_enabled.get(),
            'emote_min': self.emote_min.get(), 'emote_max': self.emote_max.get(),
            'click_min': self.click_min.get(), 'click_max': self.click_max.get(),
            'webhook_url': self.webhook_url.get().strip(), 'webhook_enabled': self.webhook_enabled.get(),
            'discord_user_id': self.discord_user_id.get().strip(), 'notify_stuck': self.notify_stuck.get(),
            'notify_game': self.notify_game.get(), 'notify_pirate': self.notify_pirate.get(),
            'notify_stages': self.notify_stages.get(), 'notify_actions': self.notify_actions.get(),
            'action_interval': self.action_interval.get(),
            'pirate_confidence': self.pirate_confidence.get(),
        }, indent=2), 'utf-8')

    def _load_templates(self):
        self.templates = {}
        for key in LABELS:
            path = TEMPLATE_DIR / f'{key}.png'
            if path.exists():
                img = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
                if img is not None and min(img.shape) >= 12:
                    self.templates[key] = img
        self.mode_templates = {}
        for mode_name in ('mode_zero_squad', 'mode_zero_solo', 'mode_build_squad'):
            mode_path = TEMPLATE_DIR / f'{mode_name}.png'
            self.mode_templates[mode_name] = cv2.imread(str(mode_path), cv2.IMREAD_GRAYSCALE) if mode_path.exists() else None
        self.mode_menu = ModeMenuRecognizer(TEMPLATE_DIR)
        self.pirate_samples = []
        for path in sorted(TEMPLATE_DIR.glob('pirate_sample_*.png')):
            img = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
            if img is not None and min(img.shape) >= 12:
                self.pirate_samples.append(img)
        for key, widget in self.capture_status.items():
            if key in self.templates:
                widget.configure(text='SAVED', foreground='#176b36')
            else:
                widget.configure(text='NOT SAVED', foreground='#a33')
        self.glide_text_template = None
        glide_path = TEMPLATE_DIR / 'glide.png'
        if glide_path.exists():
            original = cv2.imread(str(glide_path), cv2.IMREAD_COLOR)
            if original is not None:
                hsv = cv2.cvtColor(original, cv2.COLOR_BGR2HSV)
                letters = cv2.inRange(hsv, (0, 0, 175), (179, 85, 255))
                if min(letters.shape) >= 12 and 0.015 < float(np.count_nonzero(letters)) / letters.size < 0.65:
                    self.glide_text_template = letters
        self._log('Templates loaded: ' + (', '.join(self.templates) or 'none') + f'; pirate samples: {len(self.pirate_samples)}')

    def capture(self, key):
        if self.thread and self.thread.is_alive():
            messagebox.showwarning('Stop first', 'Stop the watcher before capturing templates.')
            return
        messagebox.showinfo('Capture', f'Switch to the game showing: {LABELS[key]}.\n\nAfter pressing OK, you have 3 seconds to bring the game forward. Select just the SPACE TO DEPLOY text for this prompt, or the distinctive UI element for other stages. Press ENTER; ESC cancels.')
        self.root.withdraw()
        self.root.update()
        time.sleep(3)
        try:
            img = cv2.cvtColor(np.asarray(pyautogui.screenshot()), cv2.COLOR_RGB2BGR)
            
            h, w = img.shape[:2]
            scale = min(1., 1300 / w, 800 / h)
            view = cv2.resize(img, None, fx=scale, fy=scale) if scale < 1 else img
            region = cv2.selectROI('Select image region and press ENTER', view, showCrosshair=True)
            cv2.destroyAllWindows()
            x, y, rw, rh = (round(v / scale) for v in region)
            if rw < 12 or rh < 12:
                self._log('Capture cancelled or selection too small')
                messagebox.showwarning('Capture not saved', 'No valid region selected. Drag to select an area at least 12x12 pixels, then press ENTER.')
                return
            cut = img[y:y+rh, x:x+rw]
            output = TEMPLATE_DIR / f'{key}.png'
            if not cv2.imwrite(str(output), cut):
                raise OSError(f'Could not save {output}')
            self._load_templates()
            if key not in self.templates:
                raise OSError('Screenshot saved but could not be loaded. Select a region at least 12 pixels wide and high.')
            self._log(f'SAVED {LABELS[key]} ({rw}x{rh}) to {output}')
            messagebox.showinfo('Screenshot saved', f'{LABELS[key]}\n\nSaved successfully in templates/{key}.png')
        except Exception as exc:
            self._log(f'Capture failed: {exc}')
            messagebox.showerror('Capture failed', str(exc))
        finally:
            try: cv2.destroyAllWindows()
            except Exception: pass
            self.root.deiconify()

    @staticmethod
    def _valid_webhook(url):
        u = urlparse(url)
        return (u.scheme == 'https' and u.hostname in ('discord.com', 'discordapp.com', 'canary.discord.com', 'ptb.discord.com')
                and u.path.startswith('/api/webhooks/') and len(u.path.split('/')) >= 5)

    def _webhook_sender(self):
        while True:
            url, content, test = self.webhook_queue.get()
            try:
                mentions = re.findall(r'<@(\d{17,22})>', content)
                body = json.dumps({'content': content[:2000], 'username': 'Fortnite Watcher',
                                   'allowed_mentions': {'parse': [], 'users': mentions}}).encode('utf-8')
                for attempt in range(4):
                    try:
                        req = urllib.request.Request(url, data=body, headers={
                            'Content-Type': 'application/json', 'User-Agent': 'FortniteWatcher/1.2'
                        }, method='POST')
                        with urllib.request.urlopen(req, timeout=10) as response:
                            if response.status not in (200, 204):
                                raise RuntimeError(f'HTTP {response.status}')
                        self.events.put(('webhook', 'Test sent successfully' if test else 'Last webhook sent'))
                        break
                    except urllib.error.HTTPError as exc:
                        if exc.code == 429 and attempt < 3:
                            try:
                                retry = float(json.loads(exc.read().decode('utf-8')).get('retry_after', 2))
                            except (ValueError, TypeError, json.JSONDecodeError):
                                retry = 2.0
                            time.sleep(min(max(retry, .5), 30))
                        elif exc.code in (500, 502, 503, 504) and attempt < 3:
                            time.sleep(2 ** attempt)
                        else:
                            self.events.put(('webhook', f'Webhook failed: HTTP {exc.code}'))
                            break
                    except Exception as exc:
                        if attempt < 2:
                            time.sleep(2 ** attempt)
                        else:
                            self.events.put(('webhook', f'Webhook failed: {type(exc).__name__}'))
            finally:
                self.webhook_queue.task_done()
            time.sleep(.4)

    def _send_webhook(self, url, content, test=False):
        if not url:
            return
        try:
            self.webhook_queue.put_nowait((url, content, test))
            if test:
                self.events.put(('webhook', 'Test queued...'))
        except queue.Full:
            self.events.put(('webhook', 'Webhook queue full; message skipped'))

    def test_webhook(self):
        url = self.webhook_url.get().strip()
        if not self._valid_webhook(url):
            messagebox.showerror('Invalid URL', 'Paste a Discord webhook URL starting with https://discord.com/api/webhooks/...')
            return
        try:
            self._save_config()
        except Exception as exc:
            self._log(f'Could not save settings: {exc}')
        self.webhook_status.set('Sending test...')
        self._send_webhook(url, '✅ Fortnite AFK Watcher: Test notification', test=True)

    @staticmethod
    def _pirate_score(gray, samples):
        
        
        best = 0.0
        for sample in samples:
            if np.std(sample) < 7:
                continue
            for scale in (0.65, 0.8, 1.0, 1.2, 1.4):
                if scale == 1.0:
                    tmpl = sample
                else:
                    tmpl = cv2.resize(sample, None, fx=scale, fy=scale,
                                      interpolation=cv2.INTER_AREA if scale < 1 else cv2.INTER_LINEAR)
                h, w = tmpl.shape[:2]
                if h > gray.shape[0] or w > gray.shape[1] or min(h, w) < 12:
                    continue
                score = float(cv2.minMaxLoc(cv2.matchTemplate(gray, tmpl, cv2.TM_CCOEFF_NORMED))[1])
                best = max(best, score)
        return best

    def _test_camera_turn(self):
                                                                            
        if self._camera_test_pending:
            return
        if self.thread and self.thread.is_alive():
            messagebox.showinfo('Stop the watcher', 'Press F7 to stop the watcher before testing the camera angle.')
            return
        try:
            units = int(self.turn_90_pixels.get())
            if not 200 <= units <= 30000:
                raise ValueError('90° strength must be 200–30000 relative mouse units.')
            hint = self.window_text.get().strip().lower()
            if not hint:
                raise ValueError('Enter the Fortnite window title.')
            self._save_config()
        except (ValueError, tk.TclError) as exc:
            messagebox.showerror('Invalid test settings', str(exc))
            return
        self._camera_test_pending = True
        self._camera_test_stop.clear()
        self._log('90° camera TEST: focus the Fortnite window within 3 seconds.')

        def dispatch():
            if self._camera_test_stop.is_set() or (self.thread and self.thread.is_alive()):
                self._camera_test_pending = False
                return
            if hint not in foreground_title().lower():
                self._log('Camera test cancelled: Fortnite was not focused.')
                self._camera_test_pending = False
                return

            def test_worker():
                try:
                    success = send_camera_turn(90, units, hint, self._camera_test_stop)
                    if success:
                        result = f'Camera test sent {units} relative mouse units (target: 90°). Adjust the number based on what you SEE.'
                    else:
                        result = 'Camera test interrupted (game lost focus or stopped).'
                    self.events.put(('action', result))
                except Exception as exc:
                    self.events.put(('action', f'Camera test error: {exc}'))
                finally:
                    self._camera_test_pending = False

            threading.Thread(target=test_worker, daemon=True).start()

        self.root.after(3000, dispatch)

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        if not self.window_text.get().strip():
            messagebox.showwarning('Game window required', 'Enter a unique substring of the game window title first.')
            return
        required = ('return', 'ready', 'hud', 'knocked', 'spectate')
        missing = [LABELS[k] for k in required if k not in self.templates]
        if missing:
            messagebox.showwarning('Calibration required', 'The following required screenshots are missing or invalid:\n\n' + '\n'.join('- ' + name for name in missing) + '\n\nCheck the SAVED / NOT SAVED labels beside the Capture buttons.')
            return
        try:
            threshold = float(self.threshold.get())
            if not 0.75 <= threshold <= 0.99: raise ValueError()
            pirate_threshold = float(self.pirate_confidence.get())
            if not 0.60 <= pirate_threshold <= 0.99:
                raise ValueError('Pirate confidence must be between 0.60 and 0.99')
            user_id = self.discord_user_id.get().strip()
            if user_id and (not user_id.isascii() or not user_id.isdecimal() or not 17 <= len(user_id) <= 22):
                raise ValueError('Discord User ID must be a numeric Discord ID (17-22 digits).')
            webhook_url = self.webhook_url.get().strip()
            if self.webhook_enabled.get() and webhook_url and not self._valid_webhook(webhook_url):
                raise ValueError('Enter a valid Discord webhook URL or clear the field')
            settings = [float(v.get()) for v in (self.hold_min, self.hold_max, self.click_min, self.click_max,
                                                   self.emote_min, self.emote_max)]
            lo, hi, clo, chi, elo, ehi = settings
            turn_pixels = int(self.turn_90_pixels.get())
            if not (0.2 <= lo <= hi <= 120 and 0.5 <= clo <= chi <= 60):
                raise ValueError('Set valid ranges: WASD 0.2–120 seconds, clicks 0.5–60 seconds, minimum <= maximum.')
            if not (15 <= elo <= ehi <= 600):
                raise ValueError('Emote interval must be 15–600 seconds (min <= max).')
            if not 200 <= turn_pixels <= 30000:
                raise ValueError('90-degree camera strength must be 200–30000 relative units.')
            self._save_config()
        except (ValueError, tk.TclError) as exc:
            messagebox.showerror('Invalid settings', str(exc) or 'Set confidence between 0.75 and 0.99.')
            return
        self.stop_event.clear()
        self._preferred_build_runtime = self.preferred_build.get()
                                                                                    
        self._treasure_mention = f'<@{user_id}>' if user_id else ''
                                                                           
                                                                                
                                                                             
        options = (self.window_text.get().strip().lower(), threshold, bool(self.move_enabled.get()),
                   bool(self.click_enabled.get()), lo, hi, clo, chi,
                   webhook_url if self.webhook_enabled.get() else '',
                   bool(self.notify_game.get()), bool(self.notify_pirate.get()), pirate_threshold,
                   turn_pixels, bool(self.emotes_enabled.get()), elo, ehi)
        assert len(options) == 16, 'Watcher option count must match _loop unpacking' 
        self.thread = threading.Thread(target=self._loop, args=(options,), daemon=True)
        self.thread.start()
        self._log('Watcher started. Focus the game window.')

    def stop(self):
        self._camera_test_stop.set()
        self.stop_event.set()
        self._unknown_since = None
        self._unknown_notified = False
        self.stuck_status.set('Unknown-screen timer: inactive')
        release_movement()
        self.stage.set('STOPPED')
        self.last_action.set('Stopped; movement keys released')

    def emergency(self):
        self.stop()
        self._log('EMERGENCY STOP: all movement keys released')

    def close(self):
        self.stop()
        if keyboard is not None:
            try: keyboard.unhook_all_hotkeys()
            except Exception: pass
        self.root.destroy()

    def _notification_url(self):
        if not self.webhook_enabled.get():
            return ''
        url = self.webhook_url.get().strip()
        return url if self._valid_webhook(url) else ''

    def _check_unknown_stage(self, stage):
        now = time.monotonic()
        if stage != 'WAITING / UNKNOWN SCREEN' or self.stop_event.is_set():
            self._unknown_since = None
            self._unknown_notified = False
            self.stuck_status.set('Unknown-screen timer: inactive')
            return
        if self._unknown_since is None:
            self._unknown_since = now
            self._unknown_notified = False
        elapsed = now - self._unknown_since
        if not self._unknown_notified:
            self.stuck_status.set(f'Unknown screen: {int(elapsed // 60):02d}:{int(elapsed % 60):02d} / 20:00')
            if elapsed >= 1200:
                self._unknown_notified = True
                self.stuck_status.set('Unknown screen for 20+ minutes: alert triggered')
                user_id = self.discord_user_id.get().strip()
                url = self._notification_url()
                if self.notify_stuck.get() and url and user_id.isascii() and user_id.isdecimal() and 17 <= len(user_id) <= 22:
                    self._send_webhook(url, f'<@{user_id}> ⚠️ Fortnite watcher has been on an unrecognized screen for 20 minutes. Manual attention required.')
                    self._log('Discord unknown-screen ping queued')
                else:
                    self._log('Unknown screen for 20 minutes; ping not sent (check alert enabled, User ID, and webhook)')

    def _notify_stage(self, stage):
        if stage == self._last_notified_stage:
            return
        old = self._last_notified_stage
        self._last_notified_stage = stage
        if not self.notify_stages.get() or not old:
            return
        url = self._notification_url()
        if not url:
            return
        now = time.monotonic()
        if now - self._last_stage_sent.get(stage, -10000) < 60:
            return
        self._last_stage_sent[stage] = now
        messages = {
            'PAUSED / GAME NOT FOCUSED': '⏸️ Fortnite not focused. Actions paused.',
            'WAITING / UNKNOWN SCREEN': '❔ Unknown screen. Short WASD recovery only if gameplay was previously confirmed.',
            'FORTNITE MATCHMAKING / QUEUEING': '🔎 Matchmaking: queueing for a new game.',
            'LOADING INTO FORTNITE MATCH': '⏳ Loading into Fortnite match.',
            'FORTNITE LOBBY / READYING UP': '🏠 Fortnite lobby detected.',
            'FORTNITE SQUADS / ALIVE / MOVING': '🎮 Alive in match. Movement enabled.',
            'IN STORM / CONTINUING MOVEMENT': '🟣 Inside storm. Movement continuing.',
            'KNOCKED DOWN / CRAWLING': '🩹 Knocked down. Crawling with movement keys (no sprint).',
            'ELIMINATED / SPECTATING SQUAD': '👀 Spectating squad. Movement paused.',
            'REBOOT ASSUMED / MOVING SIDEWAYS (10S)': '🔄 Spectate overlay disappeared; moving sideways (A/D) up to 10 seconds.',
            'ELIMINATED / RETURNING TO LOBBY': '🚪 Return to Lobby detected.',
            'SPACE TO DEPLOY VISIBLE / HOLDING W': '🪂 SPACE TO DEPLOY detected. Holding W only.',
            'GLIDE FINISHED / SPRINTING IMMEDIATELY': '🏃 Glide prompt disappeared. Sprinting forward immediately.',
            'SURVEY DETECTED / SKIPPING': '📋 Fortnite survey detected. Skipping.',
            'STOPPED': '🛑 Watcher stopped.'
        }
        self._send_webhook(url, messages.get(stage, f'📍 Status: {stage}'))

    def _notify_action(self, message):
        if not self.notify_actions.get() or not self._notification_url():
            return
        if message.startswith(('Webhook ', 'Webhook error:', 'Webhook request failed', 'Webhook test', '✅ Game successfully', '✅ Returning to lobby', 'Match timer started')):
            return
        category = 'movement' if message.startswith(('Held ', 'Moved ')) else (
            'camera' if message.startswith('Camera ') else (
            'emote' if message.startswith('Emoted ') else (
            'click' if message.startswith('Left-clicked') else None)))
        if category is not None:
            self._action_counts[category] = self._action_counts.get(category, 0) + 1
            return
        now = time.monotonic()
        if now - self._last_action_sent.get(message, -10000) < 20:
            return
        self._last_action_sent[message] = now
        self._send_webhook(self._notification_url(), f'⚙️ Action: {message}')

    def _flush_actions(self, force=False):
        if not self._action_counts:
            return
        now = time.monotonic()
        try:
            interval = max(15, min(300, int(self.action_interval.get())))
        except (ValueError, tk.TclError):
            interval = 30
        if not force and now - self._action_flush_at < interval:
            return
        self._action_flush_at = now
        counts = self._action_counts
        self._action_counts = {}
        url = self._notification_url()
        if url and self.notify_actions.get():
            summary = ', '.join(f'{name}: {amount}' for name, amount in sorted(counts.items()))
            self._send_webhook(url, f'🎮 Actions in last {interval}s: {summary}')

    def _drain(self):
        while True:
            try: kind, payload = self.events.get_nowait()
            except queue.Empty: break
            if kind == 'stage':
                self.stage.set(payload)
                self._check_unknown_stage(payload)
                self._notify_stage(payload)
            elif kind == 'match': self.match_info.set(payload)
            elif kind == 'action':
                self.last_action.set(payload)
                self._log(payload)
                self._notify_action(payload)
            elif kind == 'webhook': self.webhook_status.set(payload)
            elif kind == 'cmd': getattr(self, payload)()
        if self._unknown_since is not None and self.stage.get() == 'WAITING / UNKNOWN SCREEN':
            self._check_unknown_stage(self.stage.get())
        self._flush_actions()
        self.root.after(100, self._drain)

    def _detect(self, gray, threshold):
        
        matches = {}
        for key, template in self.templates.items():
            if key in ('pirate', 'glide', 'survey_skip', 'mode_custom', 'mode_lobby', 'starter', 'mode_picker', 'mode_close'): continue
            th, tw = template.shape[:2]
            if th > gray.shape[0] or tw > gray.shape[1]: continue
            if float(np.std(template)) < 7: continue  
            result = cv2.matchTemplate(gray, template, cv2.TM_CCOEFF_NORMED)
            _, confidence, _, location = cv2.minMaxLoc(result)
            matches[key] = (confidence, (location[0] + tw//2, location[1] + th//2))
        for key in ('return', 'ready', 'party_ready', 'knocked', 'spectate', 'queue', 'loading', 'hud'):
                                                                                
                                                                                 
                                                               
            needed = max(.88, threshold) if key == 'party_ready' else threshold
            if key in matches and matches[key][0] >= needed:
                return ('ready' if key == 'party_ready' else key), matches[key][0], matches[key][1]
        return 'unknown', max([v[0] for v in matches.values()], default=0.), None

    @staticmethod
    def _storm_coverage(rgb):
        h, w = rgb.shape[:2]
        sample = rgb[int(.14*h):int(.70*h), int(.12*w):int(.85*w)]
        small = cv2.resize(sample, (320, 180))
        hsv = cv2.cvtColor(small, cv2.COLOR_RGB2HSV)
        purple = cv2.inRange(hsv, (120, 45, 35), (169, 255, 255))
        return float(np.count_nonzero(purple)) / purple.size

    def _survey_match(self, gray):
        skip = self.templates.get('survey_skip')
        header_path = TEMPLATE_DIR / 'survey_title.png'
        if skip is None or not header_path.exists():
            return False, None
        header = cv2.imread(str(header_path), cv2.IMREAD_GRAYSCALE)
        if header is None:
            return False, None

        h, w = gray.shape[:2]
        lower = gray[int(h * .63):int(h * .92), int(w * .23):int(w * .76)]
        upper = gray[int(h * .04):int(h * .30), int(w * .17):int(w * .85)]
        if lower.size == 0 or upper.size == 0:
            return False, None

        def best(region, template):
            score, xy = 0.0, None
            for scale in (.8, 1.0, 1.2):
                t = cv2.resize(template, None, fx=scale, fy=scale)
                if t.shape[0] > region.shape[0] or t.shape[1] > region.shape[1]:
                    continue
                if np.std(t) < 7:
                    continue
                _, val, _, point = cv2.minMaxLoc(cv2.matchTemplate(region, t, cv2.TM_CCOEFF_NORMED))
                if val > score:
                    score = val
                    xy = (point[0] + t.shape[1] // 2, point[1] + t.shape[0] // 2)
            return score, xy

        title_score, _ = best(upper, header)
        button_score, button_xy = best(lower, skip)
        if title_score >= .78 and button_score >= .82 and button_xy:
            return True, (int(w * .23) + button_xy[0], int(h * .63) + button_xy[1])
        return False, None

    @staticmethod
    def _region_match(gray, template, bounds):
        if template is None:
            return 0.0
        height, width = gray.shape[:2]
        x0, y0, x1, y1 = bounds
        region = gray[int(height*y0):int(height*y1), int(width*x0):int(width*x1)]
        if region.size == 0 or min(template.shape) < 12 or float(np.std(template)) < 7:
            return 0.0
        th, tw = template.shape[:2]
        if th > region.shape[0] or tw > region.shape[1]:
            return 0.0
        _, score, _, _ = cv2.minMaxLoc(cv2.matchTemplate(region, template, cv2.TM_CCOEFF_NORMED))
        return float(score)

    def _custom_menu_visible(self, gray):
        custom = self._region_match(gray, self.templates.get('mode_custom'), (.50, .78, .91, 1.0))
        lobby = self._region_match(gray, self.templates.get('mode_lobby'), (.70, .78, 1.0, 1.0))
        return custom >= .81 and lobby >= .81, custom, lobby

    def _lobby_action_button(self, gray):
                                                                

                                                                         
                                                                             
                                                                             
                                                                            
           
        bounds = (0, .48, .49, 1.0)
        variants = (('PLAY', self.templates.get('ready')),
                    ('READY', self.templates.get('party_ready')))
        found = []
        for label, template in variants:
            confidence, center = self._scaled_match(gray, template, bounds, scales=(1.,))
            found.append((label, confidence, center))
        label, score, center = max(found, key=lambda v: v[1])
        if label == 'READY' and score < .88:
            return 'UNKNOWN', score, None
        if label == 'PLAY' and score < .82:
            return 'UNKNOWN', score, None
        return label, score, center

    def _ready_score(self, gray):
        return self._lobby_action_button(gray)[1]

    def _starter_visible(self, gray, ready_confidence):
        title = self._region_match(gray, self.templates.get('starter'), (0, .24, .38, .84))
        return title >= .79 and ready_confidence >= .86, title

    @staticmethod
    def _scaled_match(gray, template, bounds, scales=(.8, .9, 1.0, 1.1, 1.2)):
        if template is None:
            return 0.0, None
        h, w = gray.shape[:2]
        x0, y0, x1, y1 = bounds
        left, top = int(x0*w), int(y0*h)
        region = gray[top:int(y1*h), left:int(x1*w)]
        best_score, best_location = 0.0, None
        if region.size == 0 or np.std(template) < 6:
            return best_score, best_location
        for scale in scales:
            tw, th = round(template.shape[1]*scale), round(template.shape[0]*scale)
            if min(tw, th) < 12 or th > region.shape[0] or tw > region.shape[1]:
                continue
            resized = cv2.resize(template, (tw, th))
            _, score, _, corner = cv2.minMaxLoc(cv2.matchTemplate(region, resized, cv2.TM_CCOEFF_NORMED))
            if score > best_score:
                best_score = float(score)
                best_location = (left + corner[0] + tw//2, top + corner[1] + th//2)
        return best_score, best_location

    def _lobby_mode(self, gray):
                                                                                       
        labels = ('mode_zero_squad', 'mode_build_squad', 'mode_zero_solo')
        results = [(key, *self._scaled_match(gray, self.mode_templates.get(key), (0.025, .25, .47, .84))) for key in labels]
        key, score, position = max(results, key=lambda item: item[1])
        if score < .78:
            return 'unknown', score, None
        expected = ('mode_zero_squad' if self._preferred_build_runtime == 'Zero Build'
                    else 'mode_build_squad')
        return ('valid' if key == expected else 'invalid'), score, position

    @staticmethod
    def _mode_tile_by_colour(rgb, ready_position):
                                                                       

                                                                      
                                                                           
                                                                          
                                                                          
                                                                           
                                                                            
                                                                      
           
        if rgb is None or ready_position is None or rgb.ndim != 3:
            return None
        height, width = rgb.shape[:2]
        px, py = ready_position
        x0 = max(0, int(px - .045 * width))
        x1 = min(width, int(px + .045 * width))
        y0 = max(0, int(py - .30 * height))
                                                                        
                                                                 
        y1 = min(height, int(py - .13 * height))
        if x1 <= x0 or y1 <= y0:
            return None
        sample = rgb[y0:y1, x0:x1, :3]
        hsv = cv2.cvtColor(sample, cv2.COLOR_RGB2HSV)
        beige = cv2.inRange(hsv, (17, 65, 165), (34, 165, 248)) > 0
        good_rows = np.flatnonzero(np.mean(beige, axis=1) >= .63)
        if not len(good_rows):
            return None
                                                                           
                                                          
        runs = []
        run_start = run_end = int(good_rows[0])
        gap_limit = max(5, int(.018 * height))
        for row in good_rows[1:]:
            row = int(row)
            if row - run_end <= gap_limit:
                run_end = row
            else:
                runs.append((run_start, run_end))
                run_start = run_end = row
        runs.append((run_start, run_end))
        runs = [r for r in runs if (r[1] - r[0]) >= .042 * height]
        if not runs:
            return None
        start, end = max(runs, key=lambda r: r[1]-r[0])
                                                                          
                                                      
        region_coverage = float(beige[start:end+1].mean())
        if region_coverage < .60:
            return None
        return (int(px), int(y0 + (start + end) / 2))

    def _mode_picker_position(self, gray, mode_position, ready_position,
                              attempt=0, rgb=None):
                                                                                 
        if rgb is not None:
            tile = self._mode_tile_by_colour(rgb, ready_position)
            if tile and self._safe_mode_click(tile, ready_position, gray.shape):
                return tile, 'beige mode-selector tile (text-independent)'
                                                                        
                                                                   
        picker = self.templates.get('mode_picker')
        if picker is not None:
            score, pos = self._scaled_match(gray, picker, (0, .14, .50, .88),
                                             scales=(.8, .9, 1., 1.1, 1.2, 1.35))
            if score >= .88 and self._safe_mode_click(pos, ready_position, gray.shape):
                return pos, 'captured mode-selector fallback'
        if mode_position and self._safe_mode_click(mode_position, ready_position, gray.shape):
            return mode_position, 'recognised lobby mode label'
        return None, 'no confirmed mode tile; refusing click anywhere near Sprite'

    @staticmethod
    def _safe_mode_click(target, play, shape):
                                                                                
        if not target or not play:
            return False
        height, width = shape[:2]
        x, y = target
        px, py = play
                                                                        
                                                                           
                                                                          
                                                                       
                                                                                
        vertical_gap = py - y
        return (0.01*width <= x <= .28*width
                and .115*height <= vertical_gap <= .30*height
                and abs(x-px) <= .15*width
                and y < py - .115*height)

    def _close_mode_picker(self, gray):
                                                                              
                                                                          
        closing = self.templates.get('mode_close')
        if closing is not None:
            score, pos = self._scaled_match(gray, closing, (0, .4, .96, 1.),
                                             scales=(.8, .9, 1., 1.1, 1.2, 1.35))
            if score >= .81 and pos:
                pydirectinput.click(*pos)
                return 'clicked captured CLOSE button'
        pydirectinput.press('esc')
        return 'pressed ESC to close the options panel'

    @staticmethod
    def _settings_action(state, preferred):
                                                                             
        if not state.ranked_off:
            return 'ranked'
        if state.build != preferred:
            return preferred
        if not state.squad:
            return 'squad'
        if not state.fill:
            return 'fill'
        return None

    @staticmethod
    def _click_relative(x, y, width, height):
        pydirectinput.click(int(x*width), int(y*height))

    def _loop(self, options):
        (window_hint, threshold, movement, clicking, hold_min, hold_max, click_min, click_max,
         webhook_url, notify_game, notify_pirate, pirate_threshold, turn_90_pixels,
         emotes_enabled, emote_min, emote_max) = options
        prior = None
        count = 0
        last_click = {'return': 0., 'ready': 0.}
        last_motion = 0.
        last_guard_scan = 0.
        next_emote = time.monotonic() + random.uniform(emote_min, emote_max)
        spectate_active = False
        spectate_missing_since = None
        reboot_walk_until = 0.
        reboot_side = None
        in_game_session = False
        next_unknown_move_at = 0.
        next_attack = time.monotonic() + random.uniform(click_min, click_max)
        pirate_present_since = None
        pirate_absent_since = None
        pirate_fired = False
        game_return_fired = False
        match_started_at = None
        gliding_w_held = False
        post_glide_walk_until = 0.
        glide_misses = 0
        last_pirate_check = 0.
        treasure_scan_at = -1000.
        treasure_scan_result = False
        treasure_hits = 0
        treasure_absent_since = None
        treasure_alerted = False
        treasure_clicks = 0
        treasure_last_click = -1000.
        treasure_stuck_alerted = False
        last_glide_scan = 0.
        storm_hits = 0
        menu_started_at = None
        menu_hits = 0
        starter_hits = 0
        menu_scroll_last = 0.0
        menu_scroll_timeout = 65.0
        starter_only_until = 0.0
        mode_phase = 'idle'
        mode_phase_at = 0.0
        mode_label_hits = 0
        mode_settings_hits = 0
        mode_verified_hits = 0
        mode_last_action = 0.0
        mode_attempts = 0
        mode_verified = False
        party_ready_clicked = False                                                    
        mode_settings_misses = 0
        mode_good_hits = 0
        mode_closing_attempts = 0
        mode_actions = 0
        last_mode_scan = 0.
        last_mode_state = None
        survey_hits = 0
        last_survey_click = -1000.0
        pirate_samples = ([self.templates['pirate']] if 'pirate' in self.templates else []) + self.pirate_samples

        def check_pirate(gray, now):
            nonlocal pirate_present_since, pirate_absent_since, pirate_fired, last_pirate_check
            if not pirate_samples or now - last_pirate_check < 0.7:
                return
            last_pirate_check = now
            confidence = self._pirate_score(gray, pirate_samples)
            if confidence >= pirate_threshold:
                pirate_absent_since = None
                if pirate_present_since is None:
                    pirate_present_since = now
                
                if now - pirate_present_since >= 0.65 and not pirate_fired:
                    pirate_fired = True
                    self.events.put(('action', f'PIRATE SHOP ACCESS detected ({confidence:.2f})'))
                    if webhook_url and notify_pirate:
                        self._send_webhook(webhook_url, '🏴‍☠️ Pirate Shop Access Obtained!')
            else:
                pirate_present_since = None
                if pirate_absent_since is None:
                    pirate_absent_since = now
                
                if now - pirate_absent_since >= 10:
                    pirate_fired = False
        def see_glide(screen):
            template = self.glide_text_template
            if template is None:
                return False
            th, tw = template.shape[:2]
            if th > screen.shape[0] or tw > screen.shape[1]:
                return False
            hsv = cv2.cvtColor(screen, cv2.COLOR_RGB2HSV)
            text_pixels = cv2.inRange(hsv, (0, 0, 175), (179, 85, 255))
            _, score, _, _ = cv2.minMaxLoc(cv2.matchTemplate(text_pixels, template, cv2.TM_CCOEFF_NORMED))
            return score >= 0.66

        def set_glide(active, landed=False):
            nonlocal gliding_w_held, post_glide_walk_until
            if active and not gliding_w_held:
                post_glide_walk_until = 0.
                release_movement()
                pydirectinput.keyDown('w')
                gliding_w_held = True
                self.events.put(('action', 'SPACE TO DEPLOY visible: holding W only'))
            elif not active and gliding_w_held:
                gliding_w_held = False
                release_movement()
                if landed and movement and window_hint in foreground_title().lower() and not self.stop_event.is_set():
                                                                                     
                                                                                   
                    post_glide_walk_until = time.monotonic() + 18.
                    pydirectinput.keyDown('w')
                    pydirectinput.keyDown('ctrlleft')
                    self.events.put(('action', 'Glide prompt disappeared twice: sprinting with W + LEFT CTRL immediately (18s HUD grace)'))
                else:
                    post_glide_walk_until = 0.

        def check_survey(gray):
            nonlocal survey_hits, last_survey_click
            visible, position = self._survey_match(gray)
            survey_hits = survey_hits + 1 if visible else 0
            if visible:
                release_movement()
                if gliding_w_held:
                    set_glide(False)
                self.events.put(('stage', STAGES['survey_skip']))
                self.events.put(('match', f'Fortnite survey detected ({survey_hits} checks)'))
                if survey_hits >= 2 and time.monotonic() - last_survey_click >= 12:
                    pydirectinput.click(*position)
                    last_survey_click = time.monotonic()
                    self.events.put(('action', 'Clicked SKIP on Fortnite feedback survey'))
                return True
            return False

        def check_treasure(screen, now):
                                                                                     

                                                                                
                                                                              
                                                                               
               
            nonlocal treasure_scan_at, treasure_scan_result, treasure_hits
            nonlocal treasure_absent_since, treasure_alerted, treasure_clicks
            nonlocal treasure_last_click, treasure_stuck_alerted
            if now - treasure_scan_at < 0.35:
                return treasure_scan_result
            treasure_scan_at = now
            detected, button_xy, title_score, claim_score = self.treasure_detector.detect(screen)
            treasure_scan_result = detected
            if detected:
                treasure_absent_since = None
                treasure_hits += 1
                                                                               
                                                                                 
                release_movement()
                if gliding_w_held:
                    set_glide(False)
                self.events.put(('stage', STAGES['treasure']))
                if treasure_hits >= 2:
                    if treasure_clicks < 3 and now - treasure_last_click >= 2.0:
                        treasure_last_click = now
                        treasure_clicks += 1
                        try:
                            pydirectinput.click(*button_xy)
                            self.events.put(('action', f'TREASURE FOUND! Clicked CLAIM ALL '
                                                       f'({treasure_clicks}/3, scores {title_score:.2f}/{claim_score:.2f})'))
                            notice = '🏆 TREASURE FOUND! CLAIM ALL clicked automatically.'
                        except Exception as exc:
                            notice = '🏆 TREASURE FOUND! Auto-click failed; check the game manually.'
                            self.events.put(('action', f'Treasure claim click failed: {exc}'))
                        if not treasure_alerted:
                            treasure_alerted = True
                            if webhook_url:
                                prefix = (self._treasure_mention + ' ') if self._treasure_mention else ''
                                self._send_webhook(webhook_url, prefix + notice)
                    elif treasure_clicks >= 3 and now - treasure_last_click >= 3.0 and not treasure_stuck_alerted:
                        treasure_stuck_alerted = True
                        if webhook_url:
                            prefix = (self._treasure_mention + ' ') if self._treasure_mention else ''
                            self._send_webhook(webhook_url, prefix + '⚠️ CLAIM ALL still visible after 3 attempts. Manual attention required.')
                        self.events.put(('action', 'CLAIM ALL remained visible after 3 clicks; stopping to avoid random clicks'))
                        self.stop_event.set()
                return True
            treasure_hits = 0
            if treasure_absent_since is None:
                treasure_absent_since = now
            elif now - treasure_absent_since >= 4.0:
                                                                             
                                                                           
                treasure_alerted = False
                treasure_clicks = 0
                treasure_stuck_alerted = False
            return False

        def game_guard(force=False, current_stage=None):
                                                                                            
            nonlocal last_guard_scan, glide_misses
            if self.stop_event.is_set():
                return 'stop'
            if window_hint not in foreground_title().lower():
                return 'focus'
            now = time.monotonic()
            if not force and now - last_guard_scan < 0.45:
                return None
            last_guard_scan = now
            rgb_guard = np.asarray(pyautogui.screenshot())
            gray_guard = cv2.cvtColor(rgb_guard, cv2.COLOR_RGB2GRAY)
            if check_treasure(rgb_guard, now):
                return 'treasure'
            if self._custom_menu_visible(gray_guard)[0]:
                return 'menu'
            if check_survey(gray_guard):
                return 'survey'
            check_pirate(gray_guard, now)
            detected_guard, _, _ = self._detect(gray_guard, threshold)
                                                                                  
            if detected_guard in ('return', 'ready', 'knocked', 'spectate', 'queue', 'loading'):
                if detected_guard != 'knocked' or current_stage != 'knocked':
                    return detected_guard
            if current_stage == 'reboot' and detected_guard == 'hud':
                return 'hud'                                                            
            if see_glide(rgb_guard):
                glide_misses = 0
                set_glide(True)
                return 'glide'
            return None

        def wait_without_moving(seconds):
                                                                                  
            end = time.monotonic() + seconds
            while time.monotonic() < end:
                if game_guard():
                    return False
                if self.stop_event.wait(min(0.08, max(0, end - time.monotonic()))):
                    return False
            return game_guard(force=True) is None

        def perform_emote():
                                                                                 
            release_movement()
            if game_guard(force=True):
                return
            hold_u = random.uniform(1.0, 2.0)
            pydirectinput.keyDown('u')
            try:
                if not wait_without_moving(hold_u) or game_guard(force=True):
                    return
                                                                              
                                                                          
                slot = random.randint(1, 8)
                pydirectinput.press(str(slot))
            finally:
                pydirectinput.keyUp('u')
            duration = random.uniform(3.0, 4.0)
            self.events.put(('action', f'Emoted with U then {slot} (hold {hold_u:.1f}s; idle {duration:.1f}s)'))
            wait_without_moving(duration)

        def smooth_turn(degrees):
                                                                            
                                                                            
            if game_guard(force=True):
                return False
            success = send_camera_turn(degrees, turn_90_pixels, window_hint, self.stop_event)
            if success:
                self.events.put(('action', f'Camera sent {round(turn_90_pixels * abs(degrees) / 90)} relative units for a target {abs(degrees)}° {"right" if degrees > 0 else "left"} turn'))
            return success and game_guard(force=True) is None

        try:
            while not self.stop_event.is_set():
                if window_hint not in foreground_title().lower():
                    set_glide(False)
                    release_movement()
                    self.events.put(('stage', 'PAUSED / GAME NOT FOCUSED'))
                    self.events.put(('match', 'Focus the specified game window to continue'))
                    self.stop_event.wait(.7)
                    prior, count = None, 0
                    continue
                screenshot = pyautogui.screenshot()
                rgb = np.asarray(screenshot)
                gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
                                                                            
                                                                              
                if check_treasure(rgb, time.monotonic()):
                    self.stop_event.wait(.25)
                    continue
                now_menu = time.monotonic()
                menu_visible, menu_c, menu_l = self._custom_menu_visible(gray)
                menu_hits = menu_hits + 1 if menu_visible else 0
                if menu_started_at is None and menu_hits >= 2:
                    menu_started_at = now_menu
                    starter_hits = 0
                    set_glide(False)
                    release_movement()
                    self.events.put(('action', 'CUSTOM KEY / GO TO LOBBY detected: scrolling upward for at least 10 seconds'))
                if menu_started_at is not None:
                    release_movement()
                    elapsed_menu = now_menu - menu_started_at
                    self.events.put(('stage', STAGES['menu_scroll'] if elapsed_menu < 10 else STAGES['starter_wait']))
                    if elapsed_menu > menu_scroll_timeout:
                        self.events.put(('action', 'Menu recovery timed out after 65 seconds; stopping to prevent wrong clicks'))
                        menu_started_at = None
                        menu_hits = 0
                        self.stop_event.set()
                        break
                    if elapsed_menu >= 10:
                        found, mode_score = self._starter_visible(gray, self._ready_score(gray))
                        starter_hits = starter_hits + 1 if found and not menu_visible else 0
                        if starter_hits >= 2:
                            menu_started_at = None
                            starter_only_until = time.monotonic() + 20.0
                            menu_hits = 0
                            starter_hits = 0
                            self.events.put(('action', 'Battle Royale starter screen confirmed after 10+ seconds scrolling'))
                            prior, count = None, 0
                            self.stop_event.wait(.25)
                            continue
                    if now_menu - menu_scroll_last >= .35:
                        pyautogui.scroll(4)
                        menu_scroll_last = now_menu
                    self.events.put(('match', f'Menu recovery: {elapsed_menu:.1f}s / min 10s; CUSTOM KEY {menu_c:.2f}, GO TO LOBBY {menu_l:.2f}; starter {starter_hits}/2'))
                    self.stop_event.wait(.25)
                    continue
                now_mode = time.monotonic()
                mode_type, mode_score, mode_loc = self._lobby_mode(gray)
                lobby_action, lobby_action_score, lobby_action_location = self._lobby_action_button(gray)
                ready_visible = (lobby_action != 'UNKNOWN' and
                                 lobby_action_score >= max(.83, .88 if lobby_action == 'READY' else .83))
                                                                           
                                                                           
                                                                                
                if mode_phase != 'idle' or ready_visible or last_mode_state is not None or (not mode_verified and now_mode - last_mode_scan >= 1.5):
                    if now_mode - last_mode_scan >= .40 or mode_phase != 'idle':
                        last_mode_state = self.mode_menu.detect(rgb)
                        last_mode_scan = now_mode
                    state = last_mode_state
                else:
                    state = None
                    last_mode_state = None
                settings_visible = state is not None
                mode_settings_hits = mode_settings_hits + 1 if settings_visible else 0
                mode_settings_misses = 0 if settings_visible else mode_settings_misses + 1
                if settings_visible and mode_phase == 'idle' and mode_settings_hits >= 2:
                                                                                 
                    mode_phase, mode_phase_at = 'settings', now_mode
                    mode_verified = False
                    mode_good_hits = 0
                    self.events.put(('action', 'Detected real Fortnite Build/Zero Build settings panel'))

                if mode_phase == 'opening':
                    release_movement()
                    self.events.put(('stage', STAGES['mode_fix']))
                    if mode_settings_hits >= 2:
                        mode_phase, mode_phase_at = 'settings', now_mode
                        mode_good_hits = 0
                        mode_actions = 0
                    elif now_mode - mode_phase_at > 6:
                        if mode_attempts >= 3:
                            self.events.put(('action', 'Mode panel could not be detected; NOT pressing PLAY. Capture the optional lobby mode picker.'))
                            self.stop_event.set()
                        else:
                            mode_phase = 'idle'
                            mode_label_hits = 0
                            self.events.put(('action', 'Mode selector click did not open panel; retrying alternate location'))
                    self.stop_event.wait(.30)
                    continue

                if mode_phase == 'settings':
                    release_movement()
                    self.events.put(('stage', STAGES['mode_fix']))
                    if not settings_visible:
                        if mode_settings_misses >= 5:
                            self.events.put(('action', 'Mode menu disappeared before all four settings were verified; stopping'))
                            self.stop_event.set()
                        self.stop_event.wait(.2)
                        continue
                    if now_mode - mode_phase_at > 35 or mode_actions > 12:
                        self.events.put(('action', 'Could not verify Build, Ranked OFF, Squad, Fill after several attempts; stopping without PLAY'))
                        self.stop_event.set()
                        continue
                    action = self._settings_action(state, self._preferred_build_runtime)
                    if action is None:
                        mode_good_hits += 1
                        self.events.put(('match', f'MODE VERIFIED in menu: {state.build}, Ranked OFF, Squad, Fill ({state.confidence:.2f}) - {mode_good_hits}/2'))
                        if mode_good_hits >= 2 and now_mode - mode_last_action >= .6:
                                                                            
                                                                          
                            closing_method = self._close_mode_picker(gray)
                            mode_phase, mode_phase_at = 'closing', now_mode
                            mode_closing_attempts = 1
                            self.events.put(('action', f'All four game-mode settings visually confirmed; {closing_method}'))
                        self.stop_event.wait(.22)
                        continue
                    mode_good_hits = 0
                    self.events.put(('match', f'Mode setup: Build={state.build}; Ranked OFF={state.ranked_off}; Squad={state.squad}; Fill={state.fill}'))
                    if now_mode - mode_last_action >= .90:
                        pydirectinput.click(*state.target(action))
                        mode_actions += 1
                        mode_last_action = now_mode
                        self.events.put(('action', f'Mode selection: clicked {action} at detected menu position'))
                    self.stop_event.wait(.25)
                    continue

                if mode_phase == 'closing':
                    release_movement()
                    self.events.put(('stage', STAGES['mode_check']))
                    if settings_visible:
                        if now_mode - mode_phase_at >= 2.5 and mode_closing_attempts < 2:
                            closing_method = self._close_mode_picker(gray)
                            mode_closing_attempts += 1
                            mode_phase_at = now_mode
                            self.events.put(('action', f'Picker still visible; {closing_method} once more'))
                        elif now_mode - mode_phase_at >= 5:
                            self.events.put(('action', 'Unable to close mode picker; stopping before PLAY'))
                            self.stop_event.set()
                        self.stop_event.wait(.25)
                        continue
                    if ready_visible and mode_settings_misses >= 2:
                        if mode_type == 'invalid':
                            self.events.put(('action', 'Lobby mode label disagrees with selected settings; stopping to avoid wrong queue'))
                            self.stop_event.set()
                            continue
                        mode_phase, mode_verified = 'idle', True
                        mode_label_hits = 0
                        mode_verified_hits = 0
                        self.events.put(('action', f'Confirmed {self._preferred_build_runtime}, Ranked OFF, Squad, Fill on the menu; PLAY is now permitted'))
                    elif now_mode - mode_phase_at > 10:
                        self.events.put(('action', 'Lobby PLAY button not visible after closing settings; stopping'))
                        self.stop_event.set()
                    self.stop_event.wait(.25)
                    continue

                if ready_visible and not settings_visible and not mode_verified:
                                                                               
                                                                                
                                                                         
                    if mode_type == 'valid' and mode_score >= .86:
                        mode_verified_hits += 1
                        if mode_verified_hits >= 3:
                            mode_verified = True
                            mode_label_hits = 0
                            self.events.put(('action', 'Preferred Squad mode already shown in lobby; skipping mode menu and permitting PLAY'))
                        self.stop_event.wait(.20)
                        continue
                    mode_verified_hits = 0
                                                                           
                                                                        
                                                                     
                                                                         
                                                                               
                                                  
                    mode_label_hits += 1
                    if mode_label_hits >= 2 and now_mode - mode_last_action >= 1.:
                        release_movement()
                                                                               
                                                                       
                        ready_loc = lobby_action_location
                        target, provenance = self._mode_picker_position(gray, mode_loc, ready_loc, mode_attempts, rgb=rgb)
                        if target is None or mode_attempts >= 3:
                            self.events.put(('action', 'Mode selector tile could not be safely confirmed. NOT clicking Equip a Sprite; check the lobby screen and use optional mode-picker capture only if needed'))
                            self.stop_event.set()
                        else:
                            pydirectinput.click(*target)
                            mode_attempts += 1
                            mode_last_action = now_mode
                            mode_phase, mode_phase_at = 'opening', now_mode
                            self.events.put(('action', f'Opening mode menu using {provenance}: {target}'))
                        self.stop_event.wait(.35)
                        continue
                if ready_visible and settings_visible:
                                                                        
                    self.stop_event.wait(.30)
                    continue
                if check_survey(gray):
                    self.stop_event.wait(.25)
                    continue
                check_pirate(gray, time.monotonic())
                detected, confidence, loc = self._detect(gray, threshold)
                coverage = self._storm_coverage(rgb)
                storm_visible = coverage >= .72
                storm_hits = storm_hits + 1 if storm_visible else 0
                if storm_hits >= 2 and detected not in ('return', 'ready', 'knocked', 'spectate', 'queue', 'loading'):
                    detected, confidence, loc = 'storm', coverage, None
                deploy_visible = see_glide(rgb)
                if deploy_visible:
                    in_game_session = True
                if detected in ('return', 'ready', 'knocked', 'spectate', 'queue', 'loading'):
                                                                                     
                    post_glide_walk_until = 0.
                    glide_misses = 0
                    set_glide(False)
                elif deploy_visible:
                    glide_misses = 0
                    set_glide(True)
                elif gliding_w_held:
                    glide_misses += 1
                    if glide_misses >= 2:
                        set_glide(False, landed=True)
                count = count + 1 if detected == prior else 1
                prior = detected
                confirmed = detected if count >= 2 else 'unknown'
                now = time.monotonic()
                if confirmed in ('hud', 'storm', 'knocked', 'spectate'):
                    in_game_session = True
                elif confirmed in ('return', 'ready', 'queue', 'loading'):
                    in_game_session = False
                    next_unknown_move_at = 0.
                if confirmed in ('hud', 'storm'):
                                                                                   
                    post_glide_walk_until = 0.
                if confirmed == 'spectate':
                    spectate_active = True
                    spectate_missing_since = None
                    reboot_walk_until = 0.
                elif confirmed in ('return', 'ready', 'knocked', 'queue', 'loading'):
                    spectate_active = False
                    spectate_missing_since = None
                    reboot_walk_until = 0.
                elif confirmed in ('hud', 'storm'):
                    spectate_active = False
                    spectate_missing_since = None
                    reboot_walk_until = 0.
                elif spectate_active and detected != 'spectate':
                                                                                   
                                                                                   
                    if spectate_missing_since is None:
                        spectate_missing_since = now
                    elif now - spectate_missing_since >= 1.1:
                        spectate_active = False
                        reboot_walk_until = now + 10.0
                        reboot_side = random.choice(('a', 'd'))
                        self.events.put(('action', f'Spectate disappeared: assuming reboot, holding {reboot_side.upper()} sideways up to 10s'))
                elif spectate_active:
                    spectate_missing_since = None
                if reboot_walk_until > now and confirmed == 'unknown' and detected == 'unknown':
                    confirmed = 'reboot'
                elif post_glide_walk_until > now and confirmed == 'unknown' and detected == 'unknown':
                    confirmed = 'landing'
                elif reboot_walk_until and now >= reboot_walk_until:
                    reboot_walk_until = 0.
                    self.events.put(('action', '10s sideways reboot recovery completed; switching to short unknown-screen movements if still in-game'))
                self.events.put(('stage', STAGES[confirmed]))
                self.events.put(('match', f'Visual match: {detected} / confidence {confidence:.2f} / stable {count} frames'
                                          + (' / temporary reboot walk' if confirmed == 'reboot' else '')))
                if confirmed in ('hud', 'storm', 'knocked', 'spectate', 'queue', 'loading'):
                    game_return_fired = False
                    if confirmed in ('hud', 'storm', 'knocked', 'spectate'):
                        party_ready_clicked = False                                              
                if confirmed in ('hud', 'storm', 'knocked', 'spectate'):
                    mode_verified = False
                    mode_attempts = 0
                if gliding_w_held:
                    self.events.put(('stage', STAGES['glide']))
                    self.events.put(('match', f'SPACE TO DEPLOY: {"VISIBLE" if deploy_visible else "checking disappearance (1/2)"}'))
                    self.stop_event.wait(.20)
                    continue
                if confirmed == 'return':
                    party_ready_clicked = False
                    mode_verified = False
                    release_movement()
                    if now - last_click['return'] > 8:
                        pydirectinput.click(*loc)
                        last_click['return'] = now
                        self.events.put(('action', 'Clicked FORTNITE RETURN TO LOBBY'))
                        if not game_return_fired:
                            game_return_fired = True
                            if match_started_at is not None:
                                elapsed = max(0, time.monotonic() - match_started_at)
                                total_seconds = int(elapsed)
                                hours, remainder = divmod(total_seconds, 3600)
                                minutes, seconds = divmod(remainder, 60)
                                duration = f'{hours:02d}:{minutes:02d}:{seconds:02d}' if hours else f'{minutes:02d}:{seconds:02d}'
                                summary = f'✅ Game successfully completed... Heading back to lobby...\n⏱️ Match duration (PLAY → RETURN TO LOBBY): {duration}'
                            else:
                                summary = '✅ Returning to lobby...\n⏱️ Duration unavailable: PLAY was not clicked by this watcher.'
                            match_started_at = None
                            self.events.put(('action', summary))
                            if webhook_url and notify_game:
                                self._send_webhook(webhook_url, summary)
                elif confirmed == 'ready':
                    release_movement()
                                                                             
                                                                          
                    label, button_score, button_location = self._lobby_action_button(gray)
                    if label == 'UNKNOWN' or button_location is None:
                        self.stop_event.wait(.3)
                        continue
                    if mode_phase != 'idle' or not mode_verified:
                        self.events.put(('stage', STAGES['mode_check']))
                        self.events.put(('match', f'{label} blocked: mode settings not yet verified ({mode_type}, confidence {mode_score:.2f})'))
                        self.stop_event.wait(.35)
                        continue
                    if time.monotonic() < starter_only_until and not self._starter_visible(gray, button_score)[0]:
                        self.events.put(('match', f'Waiting for confirmed Battle Royale starter screen; {label} blocked'))
                        self.stop_event.wait(.3)
                        continue
                    if label == 'READY' and party_ready_clicked:
                        self.events.put(('match', 'Party READY already clicked; waiting for teammates or matchmaking (no extra clicks)'))
                        self.stop_event.wait(.5)
                        continue
                    if now - last_click['ready'] > 8:
                        pydirectinput.click(*button_location)
                        last_click['ready'] = now
                        if label == 'READY':
                            party_ready_clicked = True
                            self.events.put(('action', 'Clicked party READY once; waiting for other players (NOT READY will never be clicked)'))
                        else:
                            party_ready_clicked = False
                            self.events.put(('action', 'Clicked solo PLAY'))
                        if match_started_at is None:
                            match_started_at = time.monotonic()
                            self.events.put(('action', f'Match timer started when {label} was clicked'))
                elif confirmed in ('hud', 'storm', 'knocked', 'reboot', 'landing') or (confirmed == 'unknown' and detected == 'unknown' and in_game_session and not ready_visible and not settings_visible):
                                                                                            
                                                                               
                    alive_confirmed = confirmed in ('hud', 'storm')
                    landing_recovery = confirmed == 'landing'
                    unknown_recovery = confirmed == 'unknown'
                    if not movement:
                        release_movement()
                    elif unknown_recovery and now < next_unknown_move_at:
                        release_movement()                                                
                    elif alive_confirmed and emotes_enabled and now >= next_emote:
                        next_emote = now + random.uniform(emote_min, emote_max)
                        perform_emote()
                    elif now - last_motion >= 0.05:
                        recovery_until = post_glide_walk_until if landing_recovery else reboot_walk_until
                        keys, duration, sprint = movement_profile(
                            confirmed, now, recovery_until, reboot_side, hold_min, hold_max)
                        interrupted = None
                        if duration > 0 and keys:
                            try:
                                for key in keys:
                                    pydirectinput.keyDown(key)
                                                                                      
                                                                                             
                                                                         
                                if sprint:
                                    pydirectinput.keyDown('ctrlleft')
                                if alive_confirmed and random.random() < 0.25:
                                    pydirectinput.press('space')
                                if alive_confirmed and random.random() < .75:
                                    angle = random.choice((-180, -90, 90, 180))
                                    if not smooth_turn(angle):
                                        interrupted = 'turn'
                                end_hold = time.monotonic() + duration
                                while interrupted is None and time.monotonic() < end_hold:
                                    interrupted = game_guard(current_stage=confirmed)
                                    if interrupted:
                                        break
                                    if clicking and alive_confirmed and time.monotonic() >= next_attack:
                                        pydirectinput.click(button='left')
                                        next_attack = time.monotonic() + random.uniform(click_min, click_max)
                                        self.events.put(('action', 'Left-clicked while moving'))
                                    if self.stop_event.wait(0.08):
                                        interrupted = 'stop'
                                        break
                            finally:
                                if not gliding_w_held:
                                    release_movement()
                            last_motion = time.monotonic()
                            if unknown_recovery:
                                next_unknown_move_at = last_motion + random.uniform(1.8, 3.0)
                            self.events.put(('action', f'Held {"+".join(keys).upper()}'
                                                        + (' + LEFT CTRL' if sprint else '')
                                                        + f' for up to {duration:.1f}s ({confirmed})'
                                                        + (' (interrupted by screen/focus)' if interrupted else '')))
                else:
                    release_movement()
                self.stop_event.wait(.08)
        except Exception as exc:
            self.events.put(('action', f'Automation stopped after an error: {exc}'))
        finally:
            set_glide(False)
            release_movement()
            self.events.put(('stage', 'STOPPED'))
            self.stop_event.set()


if __name__ == '__main__':
    if not hasattr(ctypes, 'windll'):
        raise SystemExit('This tool requires Windows.')
    root = tk.Tk()
    WatcherApp(root)
    root.mainloop()
