                                                                         

                                                                         
                                                                           
                                                                           
   
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

                                                          
REFERENCE_CROPS = {
    "team": (22, 282, 158, 310),                                            
    "fill": (22, 409, 138, 437),                                           
    "ranked": (22, 158, 114, 184),                                       
    "off": (22, 182, 89, 211),                        
    "squad": (22, 311, 120, 339),                          
    "fill_value": (22, 436, 102, 463),                         
}

@dataclass(frozen=True)
class ModeMenuState:
    x: int
    y: int
    scale: float
    confidence: float
    build: str                                                   
    ranked_off: bool
    squad: bool
    fill: bool

    def target(self, name: str):
                                                                            
                                                                           
        positions = {
            'Build': (165, 55),
            'Zero Build': (475, 55),
            'ranked': (520, 184),
            'squad': (582, 306),
            'fill': (520, 435),
        }
        xp, yp = positions[name]
        return (int(round(self.x + xp*self.scale)), int(round(self.y + yp*self.scale)))

    def correct(self, preferred):
        return (self.build == preferred and self.ranked_off and self.squad and self.fill)


class ModeMenuRecognizer:
    def __init__(self, template_folder):
        folder = Path(template_folder)
        self.templates = {}
        for key in REFERENCE_CROPS:
            path = folder / f'ui2026_{key}.png'
            img = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE) if path.is_file() else None
            self.templates[key] = img

    @staticmethod
    def _score_near(gray, template, ox, oy, scale, crop, slack=9):
        if template is None:
            return 0.
        tw = max(4, round(template.shape[1]*scale))
        th = max(4, round(template.shape[0]*scale))
        needle = cv2.resize(template, (tw, th)) if abs(scale-1) > 1e-5 else template
        px = round(ox + crop[0]*scale)
        py = round(oy + crop[1]*scale)
        pad = round(slack*scale) + 2
        x0, y0 = max(0, px-pad), max(0, py-pad)
        x1, y1 = min(gray.shape[1], px+tw+pad), min(gray.shape[0], py+th+pad)
        section = gray[y0:y1, x0:x1]
        if section.shape[0] < th or section.shape[1] < tw:
            return 0.
        _, value, _, _ = cv2.minMaxLoc(cv2.matchTemplate(section, needle, cv2.TM_CCOEFF_NORMED))
        return float(value)

    @staticmethod
    def _yellow_fraction(rgb, origin_x, origin_y, scale, rect):
        x0, y0, x1, y1 = rect
        px0 = max(0, round(origin_x + x0*scale)); py0 = max(0, round(origin_y + y0*scale))
        px1 = min(rgb.shape[1], round(origin_x + x1*scale))
        py1 = min(rgb.shape[0], round(origin_y + y1*scale))
        if px1 <= px0 or py1 <= py0:
            return 0.
        patch = rgb[py0:py1, px0:px1]
        r = patch[:,:,0].astype(np.int16)
        g = patch[:,:,1].astype(np.int16)
        b = patch[:,:,2].astype(np.int16)
        yellow = (r > 175) & (g > 155) & (b < 135) & (r > b + 65) & (g > b + 65)
        return float(yellow.mean())

    def detect(self, rgb):
        if any(self.templates[k] is None for k in ('team','fill','ranked')):
            return None
        gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
        team = self.templates['team']
        best = None
        best_score = 0.
                                                                              
                                                                             
        for scale in (.65, .75, .85, 1., 1.1, 1.2, 1.33, 1.5, 1.75):
            tw, th = round(team.shape[1]*scale), round(team.shape[0]*scale)
            if tw >= gray.shape[1] or th >= gray.shape[0]:
                continue
            needle = cv2.resize(team, (tw, th)) if scale != 1 else team
                                                                     
            region = gray[:int(gray.shape[0]*.92), :int(gray.shape[1]*.75)]
            if region.shape[0] < th or region.shape[1] < tw:
                continue
            result = cv2.matchTemplate(region, needle, cv2.TM_CCOEFF_NORMED)
            _, team_score, _, (tx, ty) = cv2.minMaxLoc(result)
            if team_score < .73:
                continue
            origin_x = round(tx - REFERENCE_CROPS['team'][0]*scale)
            origin_y = round(ty - REFERENCE_CROPS['team'][1]*scale)
            if origin_x < -25*scale or origin_y < -25*scale:
                continue
            fill_score = self._score_near(gray, self.templates['fill'], origin_x, origin_y, scale,
                                          REFERENCE_CROPS['fill'])
            ranked_score = self._score_near(gray, self.templates['ranked'], origin_x, origin_y, scale,
                                            REFERENCE_CROPS['ranked'])
            if min(fill_score, ranked_score) < .73:
                continue
            combined = min(float(team_score), fill_score, ranked_score)
            if combined > best_score:
                best = (origin_x, origin_y, scale, combined)
                best_score = combined
        if best is None:
            return None
        x, y, scale, confidence = best
        yellow = lambda rect: self._yellow_fraction(rgb, x, y, scale, rect)
                                                                          
                                                               
        build_underline = yellow((30, 80, 304, 91))
        zero_underline = yellow((334, 80, 609, 91))
        if build_underline > .17 and build_underline > zero_underline*1.5:
            build = 'Build'
        elif zero_underline > .17 and zero_underline > build_underline*1.5:
            build = 'Zero Build'
        else:
            build = 'unknown'
        squad_underline = yellow((552, 332, 615, 347)) > .07
        squad_caption = self._score_near(gray, self.templates['squad'], x, y, scale,
                                         REFERENCE_CROPS['squad']) >= .77
        off_caption = self._score_near(gray, self.templates['off'], x, y, scale,
                                       REFERENCE_CROPS['off']) >= .76
                                                                            
        fill_caption = self._score_near(gray, self.templates['fill_value'], x, y, scale,
                                        REFERENCE_CROPS['fill_value']) >= .77
        fill_selected = yellow((481, 414, 526, 458)) > .14 and fill_caption
        return ModeMenuState(x=x, y=y, scale=scale, confidence=confidence,
                             build=build, ranked_off=off_caption,
                             squad=squad_underline and squad_caption, fill=fill_selected)
