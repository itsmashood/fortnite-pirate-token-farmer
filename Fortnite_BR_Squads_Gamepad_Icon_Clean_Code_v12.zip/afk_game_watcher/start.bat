@echo off
cd /d "%~dp0"
py afk_watcher.py
if errorlevel 1 pause
