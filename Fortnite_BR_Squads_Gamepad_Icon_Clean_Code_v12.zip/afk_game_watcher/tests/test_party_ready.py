                                                                                
import ast
from pathlib import Path
import unittest
import cv2
import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
SCREENSHOTS=[HERE/'fixtures'/'solo_lobby.png',
             HERE/'fixtures'/'party_lobby.png']
                                                                          
                                                 
module=ast.parse((ROOT/'afk_watcher.py').read_text(encoding='utf8'))
klass=next(x for x in module.body if isinstance(x,ast.ClassDef) and x.name=='WatcherApp')
ns={'cv2':cv2, 'np':np, '__name__':'headless_methods'}
exec(compile(ast.fix_missing_locations(ast.Module(body=[klass],type_ignores=[])),
             '<watcher-methods>', 'exec'), ns)
App=ns['WatcherApp']

class TestPartyReady(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=App.__new__(App)
        names=('ready','party_ready','return','hud','knocked','spectate')
        cls.app.templates={k:cv2.imread(str(ROOT/'templates'/f'{k}.png'),cv2.IMREAD_GRAYSCALE)
                           for k in names}
        cls.app.mode_templates={k:cv2.imread(str(ROOT/'templates'/f'{k}.png'),cv2.IMREAD_GRAYSCALE)
                                for k in ('mode_zero_squad','mode_zero_solo','mode_build_squad')}
        cls.app._preferred_build_runtime='Zero Build'

    def gray(self,idx):
        self.assertTrue(SCREENSHOTS[idx].exists())
        g=cv2.imread(str(SCREENSHOTS[idx]),cv2.IMREAD_GRAYSCALE)
        self.assertIsNotNone(g)
        return g

    def test_solo_play_is_found(self):
        g=self.gray(0)
        label,score,loc=self.app._lobby_action_button(g)
        self.assertEqual(label,'PLAY')
        self.assertGreater(score,.94)
        self.assertTrue(850 < loc[1] < 970)
        self.assertEqual(self.app._detect(g,.86)[0],'ready')

    def test_party_ready_is_found(self):
        g=self.gray(1)
        label,score,loc=self.app._lobby_action_button(g)
        self.assertEqual(label,'READY')
        self.assertGreater(score,.94)
        self.assertTrue(850 < loc[1] < 970)
        self.assertEqual(self.app._detect(g,.86)[0],'ready')
        self.assertGreater(self.app._ready_score(g),.94)

    def test_existing_play_does_not_match_party_as_play(self):
        g=self.gray(1)
        play_score=self.app._region_match(g,self.app.templates['ready'],(0,.48,.49,1.))
        self.assertLess(play_score,.83)

    def test_mode_label_still_correct_in_party(self):
        for i in (0,1):
            typ,score,loc=self.app._lobby_mode(self.gray(i))
            self.assertEqual(typ,'valid')
            self.assertGreater(score,.90)

    def test_sprite_area_cannot_be_mode_picker(self):
        for i in (0,1):
            g=self.gray(i)
            _,_,button=self.app._lobby_action_button(g)
            _,_,correct_label=self.app._lobby_mode(g)
            self.assertTrue(self.app._safe_mode_click(correct_label,button,g.shape))
                                                                           
            sprite_loc=(button[0],button[1]-96)
            self.assertFalse(self.app._safe_mode_click(sprite_loc,button,g.shape))

    def test_no_click_target_without_genuine_button(self):
        g=np.zeros_like(self.gray(1))
        label,score,loc=self.app._lobby_action_button(g)
        self.assertEqual(label,'UNKNOWN')
        self.assertIsNone(loc)
        self.assertNotEqual(self.app._detect(g,.86)[0],'ready')

if __name__=='__main__':unittest.main()
