                                                                                
import ast
import random
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SOURCE = (ROOT / 'afk_watcher.py').read_text(encoding='utf8')
TREE = ast.parse(SOURCE)
PROFILE = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == 'movement_profile')
ns = {'random': random}
exec(compile(ast.fix_missing_locations(ast.Module(body=[PROFILE], type_ignores=[])), '<movement-profile>', 'exec'), ns)
profile = ns['movement_profile']


class SpecialMovementTests(unittest.TestCase):
    def test_knocked_movement_is_active_and_does_not_sprint(self):
        for i in range(40):
            keys, sec, sprint = profile('knocked', 0, 0, None, 25, 45, random.Random(i))
            self.assertEqual(len(keys), 1)
            self.assertIn(keys[0], 'wasd')
            self.assertGreaterEqual(sec, 5.0)
            self.assertLessEqual(sec, 8.0)
            self.assertFalse(sprint)

    def test_unknown_has_short_key_holds_and_never_sprints(self):
        for i in range(40):
            keys, sec, sprint = profile('unknown', 0, 0, None, 25, 45, random.Random(i))
            self.assertEqual(len(keys), 1)
            self.assertIn(keys[0], 'wasd')
            self.assertGreaterEqual(sec, 1.8)
            self.assertLessEqual(sec, 2.6)
            self.assertFalse(sprint)

    def test_reboot_uses_only_sideways_and_stops_at_ten_seconds(self):
        for side in 'ad':
            for now, expected in [(10.0, 10.0), (15.0, 5.0), (19.9, 0.1)]:
                keys, seconds, sprint = profile('reboot', now, 20.0, side, 25, 45)
                self.assertEqual(keys, (side,))
                self.assertAlmostEqual(seconds, expected)
                self.assertFalse(sprint)
            self.assertEqual(profile('reboot', 20, 20, side, 25, 45), ((), 0., False))
        self.assertEqual(profile('reboot', 10, 20, None, 25, 45), ((), 0., False))

    def test_normal_alive_still_uses_long_sprints(self):
        keys, seconds, sprint = profile('hud', 20, 0, None, 25, 45, random.Random(20))
        self.assertTrue(keys)
        self.assertTrue(25 <= seconds <= 45)
        self.assertTrue(sprint)

    def test_landing_keeps_w_and_sprint(self):
        keys, seconds, sprint = profile('landing', 20, 26, None, 25, 45, random.Random(21))
        self.assertEqual(keys, ('w',))
        self.assertEqual(seconds, 6)
        self.assertTrue(sprint)

    def test_loop_handles_knocked_and_unknown_with_priority_checks(self):
        klass = next(n for n in TREE.body if isinstance(n, ast.ClassDef) and n.name == 'WatcherApp')
        loop = next(n for n in klass.body if isinstance(n, ast.FunctionDef) and n.name == '_loop')
        guard = next(n for n in ast.walk(loop) if isinstance(n, ast.FunctionDef) and n.name == 'game_guard')
        args = [a.arg for a in guard.args.args]
        self.assertIn('current_stage', args)
        src = ast.get_source_segment(SOURCE, loop)
        self.assertIn("confirmed == 'unknown' and detected == 'unknown' and in_game_session and not ready_visible and not settings_visible", src)
        self.assertIn("reboot_walk_until = now + 10.0", src)
        self.assertIn("game_guard(current_stage=confirmed)", src)
        self.assertIn("next_unknown_move_at = last_motion + random.uniform(1.8, 3.0)", src)
        self.assertIn("detected_guard != 'knocked' or current_stage != 'knocked'", src)
        self.assertIn("if sprint:", src)


if __name__ == '__main__':
    unittest.main()
