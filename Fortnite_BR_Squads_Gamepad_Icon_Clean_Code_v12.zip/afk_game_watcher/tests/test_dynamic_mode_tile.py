                                                                               
                                                                   
   
import ast
from pathlib import Path
import unittest
import cv2
import numpy as np

ROOT=Path(__file__).resolve().parent.parent
module=ast.parse((ROOT/'afk_watcher.py').read_text(encoding='utf8'))
klass=next(x for x in module.body if isinstance(x,ast.ClassDef) and x.name=='WatcherApp')
ns={'cv2':cv2,'np':np,'__name__':'test_methods'}
exec(compile(ast.fix_missing_locations(ast.Module(body=[klass],type_ignores=[])),
             '<watcher>', 'exec'),ns)
App=ns['WatcherApp']

class TestDynamicModeTile(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=App.__new__(App)
        cls.app.templates={
            'ready':cv2.imread(str(ROOT/'templates/ready.png'),0),
            'party_ready':cv2.imread(str(ROOT/'templates/party_ready.png'),0),
        }
        cls.app.mode_templates={k:cv2.imread(str(ROOT/'templates'/f'{k}.png'),0)
                                for k in ('mode_zero_squad','mode_build_squad','mode_zero_solo')}
        cls.app._preferred_build_runtime='Zero Build'

    def _screen(self,variant,scale=1.0):
        image=cv2.imread(str(ROOT/'tests/fixtures'/f'{variant}_lobby.png'))
        self.assertIsNotNone(image)
        if scale!=1.0:
            image=cv2.resize(image,None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA)
        return cv2.cvtColor(image,cv2.COLOR_BGR2RGB)

    def _target(self,screen):
        gray=cv2.cvtColor(screen,cv2.COLOR_RGB2GRAY)
        label,score,play=self.app._lobby_action_button(gray)
        self.assertIn(label,('READY','PLAY'))
        self.assertIsNotNone(play)
        mode,mode_score,mode_position=self.app._lobby_mode(gray)
        location,source=self.app._mode_picker_position(gray,mode_position,play,rgb=screen)
        return location,source,play

    def test_solo_and_party_both_locate_beige_tile(self):
        for variant in ('solo','party'):
            with self.subTest(variant=variant):
                im=self._screen(variant)
                loc,source,play=self._target(im)
                self.assertIn('text-independent',source)
                self.assertTrue(self.app._safe_mode_click(loc,play,im.shape))
                self.assertGreater(play[1]-loc[1],.14*im.shape[0])
                self.assertLess(play[1]-loc[1],.25*im.shape[0])

    def test_other_mode_names_do_not_move_click_to_sprite(self):
        for variant in ('solo','party'):
            base=self._screen(variant)
            for text in ('Build, Solo','Zero Build, Duos','Ranked, Trios','Zero Build, Squad, No Fill'):
                with self.subTest(variant=variant,text=text):
                    altered=base.copy()
                                                                                   
                    cv2.rectangle(altered,(150,685),(405,756),(212,196,125),-1)
                    cv2.putText(altered,text[:16],(146,715),cv2.FONT_HERSHEY_SIMPLEX,
                                .70,(25,20,25),2,cv2.LINE_AA)
                    loc,source,play=self._target(altered)
                    self.assertIn('text-independent',source)
                    self.assertTrue(self.app._safe_mode_click(loc,play,altered.shape))
                    self.assertLess(loc[1],770)

    def test_resized_lobby(self):
        for scale in (.75,.833333,1.0,1.15):
            with self.subTest(scale=scale):
                screen=self._screen('solo',scale)
                                                                             
                                                                                          
                play=(round(261*scale),round(913*scale))
                loc=self.app._mode_tile_by_colour(screen,play)
                self.assertIsNotNone(loc)
                self.assertTrue(self.app._safe_mode_click(loc,play,screen.shape))

    def test_unrelated_beige_patch_outside_safe_band_does_not_click(self):
        screen=np.zeros_like(self._screen('solo'))
        fake_ready=(260,913)
                                                             
        cv2.rectangle(screen,(105,780),(420,865),(212,196,125),-1)
        tile=self.app._mode_tile_by_colour(screen,fake_ready)
        self.assertIsNone(tile)

    def test_no_beige_tile_no_new_target(self):
        screen=np.zeros_like(self._screen('solo'))
        self.assertIsNone(self.app._mode_tile_by_colour(screen,(260,913)))

if __name__=='__main__':unittest.main()
