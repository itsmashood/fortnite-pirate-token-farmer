                                                                                  
import queue
import sys
import threading
import types
import unittest
from pathlib import Path

import cv2
import numpy as np

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from treasure_detector import TreasureDetector


def reference_screen():
                                                                              
    frame = np.zeros((1080, 1920, 3), dtype=np.uint8)
    frame[:] = (164, 116, 70)
    folder = HERE / 'templates'
    title = cv2.imread(str(folder / 'treasure_title_mask.png'), 0)
    claim = cv2.imread(str(folder / 'treasure_claim_mask.png'), 0)
    tx, ty = 76, 296
    frame[ty:ty + title.shape[0], tx:tx + title.shape[1]][title > 0] = (255, 255, 255)
    frame[955:1017, 807:1110] = (255, 229, 182)
    cx, cy = 886, 973
    frame[cy:cy + claim.shape[0], cx:cx + claim.shape[1]][claim > 0] = (47, 37, 22)
    return frame


class TreasureRecognitionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.detector = TreasureDetector(HERE / 'templates')

    def test_two_text_anchors_and_real_target(self):
        confirmed, pos, title, claim = self.detector.detect(reference_screen())
        self.assertTrue(confirmed)
        self.assertEqual(pos, (962, 987))
        self.assertGreater(title, .9)
        self.assertGreater(claim, .9)

    def test_scales_and_click_position(self):
        for w, h in ((1600, 900), (1366, 768), (2560, 1440), (1280, 720)):
            with self.subTest(size=(w, h)):
                img = cv2.resize(reference_screen(), (w, h), interpolation=cv2.INTER_AREA)
                confirmed, (x, y), _, _ = self.detector.detect(img)
                self.assertTrue(confirmed)
                self.assertAlmostEqual(x, 962 * w / 1920, delta=5)
                self.assertAlmostEqual(y, 987 * h / 1080, delta=5)

    def test_never_clicks_on_just_treasure_heading(self):
        frame = reference_screen()
        frame[940:1060, 600:1300] = (164, 116, 70)
        self.assertFalse(self.detector.detect(frame)[0])

    def test_never_clicks_on_just_claim_button(self):
        frame = reference_screen()
        frame[240:370, :700] = (164, 116, 70)
        self.assertFalse(self.detector.detect(frame)[0])

    def test_unrelated_screens_rejected(self):
        self.assertFalse(self.detector.detect(np.zeros((720, 1280, 3), dtype=np.uint8))[0])
        rng = np.random.default_rng(42)
        self.assertFalse(self.detector.detect(rng.integers(0, 256, size=(720, 1280, 3), dtype=np.uint8))[0])

    def test_visual_colours_may_change(self):
        frame = reference_screen()
        frame[955:1017, 807:1110] = (239, 215, 163)
        claim = cv2.imread(str(HERE / 'templates' / 'treasure_claim_mask.png'), 0)
        frame[973:1002, 886:1039][claim > 0] = (33, 23, 19)
        self.assertTrue(self.detector.detect(frame)[0])


class TreasureWatcherFlowTests(unittest.TestCase):
    def test_screen_claims_and_notifies_once_without_gui_option(self):
                                                                                  
        fake = types.SimpleNamespace(FAILSAFE=True, PAUSE=0.,
                                     keyDown=lambda *a, **kw: None,
                                     keyUp=lambda *a, **kw: None,
                                     moveRel=lambda *a, **kw: None,
                                     press=lambda *a, **kw: None,
                                     click=lambda *a, **kw: None)
        sys.modules.setdefault('pyautogui', fake)
        sys.modules.setdefault('pydirectinput', fake)
        import afk_watcher
        watcher = object.__new__(afk_watcher.WatcherApp)
        watcher.treasure_detector = TreasureDetector(HERE / 'templates')
        watcher.events = queue.Queue()
        watcher.stop_event = threading.Event()
        watcher._treasure_mention = '<@123456789012345678>'
        watcher.templates = {}
        watcher.pirate_samples = []
        watcher.glide_text_template = None
        watcher._preferred_build_runtime = 'Zero Build'
        sent, clicks = [], []
        watcher._send_webhook = lambda url, content: sent.append((url, content))
        screenshot = reference_screen()
        original_screen = getattr(afk_watcher.pyautogui, 'screenshot', None)
        original_click = afk_watcher.pydirectinput.click
        original_foreground = afk_watcher.foreground_title
        afk_watcher.pyautogui.screenshot = lambda: screenshot
        afk_watcher.foreground_title = lambda: 'Fortnite'
        def click(x, y):
            clicks.append((x, y))
            watcher.stop_event.set()
        afk_watcher.pydirectinput.click = click
        options = ('fortnite', .86, True, False, 25., 45., 3., 7.,
                   'https://discord.com/api/webhooks/123456789012345678/FAKE',
                   True, True, .72, 4800, True, 50., 100.)
        try:
            thread = threading.Thread(target=watcher._loop, args=(options,), daemon=True)
            thread.start()
            thread.join(timeout=4.)
            watcher.stop_event.set()
            self.assertFalse(thread.is_alive(), 'Treasure handler failed to react within four seconds')
            self.assertEqual(clicks, [(962, 987)])
            self.assertEqual(len(sent), 1)
            self.assertIn('TREASURE FOUND', sent[0][1])
            self.assertIn('CLAIM ALL', sent[0][1])
            self.assertIn('<@123456789012345678>', sent[0][1])
        finally:
            if original_screen is None:
                delattr(afk_watcher.pyautogui, 'screenshot')
            else:
                afk_watcher.pyautogui.screenshot = original_screen
            afk_watcher.pydirectinput.click = original_click
            afk_watcher.foreground_title = original_foreground


if __name__ == '__main__':
    unittest.main()
