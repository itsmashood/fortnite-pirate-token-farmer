                                                                            
import unittest
import sys
import types
from pathlib import Path

import cv2
import numpy as np

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from mode_selector import ModeMenuRecognizer


def watcher_class():
                                                                                
    fake = types.SimpleNamespace(
        FAILSAFE=True, PAUSE=0., click=lambda *args, **kwargs: None,
        press=lambda *args, **kwargs: None,
        keyDown=lambda *args, **kwargs: None,
        keyUp=lambda *args, **kwargs: None,
        moveRel=lambda *args, **kwargs: None,
    )
    sys.modules.setdefault('pyautogui', fake)
    sys.modules.setdefault('pydirectinput', fake)
    import afk_watcher
    return afk_watcher.WatcherApp


class TestBattleRoyaleModePanel(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.recogniser = ModeMenuRecognizer(HERE / 'templates')
        ref_path = HERE / 'tests' / 'mode_reference.png'
        cls.reference = cv2.cvtColor(cv2.imread(str(ref_path)), cv2.COLOR_BGR2RGB)
        cls.Watcher = watcher_class()

    def panel(self, position=(50, 15), scale=1., background=(29, 29, 29)):
        canvas = np.zeros((1080, 1920, 3), dtype=np.uint8)
        canvas[:,:,:] = background
        src = self.reference
        if scale != 1:
            src = cv2.resize(src, (round(src.shape[1]*scale), round(src.shape[0]*scale)))
        x, y = position
        canvas[y:y+src.shape[0], x:x+src.shape[1]] = src
        return canvas

    def test_actual_user_screenshot(self):
        state = self.recogniser.detect(self.reference)
        self.assertIsNotNone(state)
        self.assertEqual(state.build, 'Build')
        self.assertTrue(state.ranked_off)
        self.assertTrue(state.squad)
        self.assertTrue(state.fill)
        self.assertEqual(self.Watcher._settings_action(state, 'Build'), None)
        self.assertEqual(self.Watcher._settings_action(state, 'Zero Build'), 'Zero Build')

    def test_menu_translates_and_scales(self):
        for scale, pos in ((.85, (90, 30)), (1.0, (280, 110)), (1.2, (15, 35))):
            with self.subTest(scale=scale, position=pos):
                state = self.recogniser.detect(self.panel(pos, scale))
                self.assertIsNotNone(state)
                self.assertEqual(state.build, 'Build')
                self.assertTrue(state.correct('Build'))
                x, y = state.target('Zero Build')
                self.assertAlmostEqual(x, pos[0] + 475*scale, delta=3)
                self.assertAlmostEqual(y, pos[1] + 55*scale, delta=3)

    def test_build_vs_zero_build_selected_by_yellow_underline(self):
        altered = self.reference.copy()
                                                               
        altered[80:91, 23:311, :] = self.reference[72:83, 23:311, :]
        altered[80:91, 327:615, :] = self.reference[80:91, 23:311, :]
        state = self.recogniser.detect(altered)
        self.assertEqual(state.build, 'Zero Build')
        self.assertTrue(state.correct('Zero Build'))

    def test_squad_fill_and_ranked_mismatches_choose_only_one_click(self):
        screenshot = self.reference.copy()
                                          
        screenshot[334:347, 552:615, :] = (75, 38, 204)
        state = self.recogniser.detect(screenshot)
        self.assertFalse(state.squad)
        self.assertEqual(self.Watcher._settings_action(state, 'Build'), 'squad')
                                                                      
        screenshot = self.reference.copy()
        screenshot[413:460, 481:528, :] = (78, 44, 190)
        state = self.recogniser.detect(screenshot)
        self.assertFalse(state.fill)
        self.assertEqual(self.Watcher._settings_action(state, 'Build'), 'fill')
                                                      
        screenshot = self.reference.copy()
        screenshot[185:210, 22:91, :] = (30, 15, 78)
        state = self.recogniser.detect(screenshot)
        self.assertFalse(state.ranked_off)
        self.assertEqual(self.Watcher._settings_action(state, 'Build'), 'ranked')

    def test_non_panel_never_triggers_game_mode_click(self):
        random_scene = np.random.default_rng(42).integers(0,255,(700,1000,3),dtype=np.uint8)
        self.assertIsNone(self.recogniser.detect(random_scene))
        self.assertIsNone(self.recogniser.detect(np.zeros((720,1280,3), np.uint8)))

    def test_never_guesses_a_sprite_row_click(self):
        watcher = object.__new__(self.Watcher)
        watcher.templates = {}
        screenshot = np.zeros((928,1648), dtype=np.uint8)
        xy, _ = watcher._mode_picker_position(screenshot, None, (210,790),0)
        self.assertIsNone(xy)
        xy, _ = watcher._mode_picker_position(screenshot, (200,725), (210,790),0)
        self.assertIsNone(xy)                                   
        xy, why = watcher._mode_picker_position(screenshot, (200,670), (210,790),0)
        self.assertEqual(xy, (200,670))
        self.assertEqual(why, 'recognised lobby mode label')
        xy, _ = watcher._mode_picker_position(screenshot, (600,670), (210,790),0)
        self.assertIsNone(xy)


if __name__ == '__main__':
    unittest.main()
