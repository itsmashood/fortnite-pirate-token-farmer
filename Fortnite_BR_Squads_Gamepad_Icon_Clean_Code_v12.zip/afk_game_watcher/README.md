# Fortnite BR Squads AFK Watcher – Webhook Edition

**Windows / Python prototype.** Untested within Fortnite. Simulated inputs may not work, and unattended automation may violate Epic's game rules. No game memory reads, anti-cheat bypass or network manipulation.

## v10: game-mode selector when lobby text changes

The lobby can display **Solo, Duos, Trios, Squad, Fill, No Fill**, or another current mode.
The watcher now recognises the **beige mode-selector tile by its shape and colour**, not
by exact text. It anchors the tile's safe screen area to the detected PLAY / READY
button, excludes **Equip a Sprite**, and opens the mode menu only when the known
preferred Squad label doesn't already match. Within the menu it verifies your
Build / Zero Build preference, Ranked OFF, Squad and Fill before readying up.

You no longer need a separate captured PNG for every possible lobby mode. An
optional selector capture remains available as a fallback for unusual theme/
colour changes. Keep existing `config.json` and saved `templates` while updating.
Test the first party/solo queue while watching: live Fortnite has not been tested.

## Start

1. Extract the ZIP to its own folder.
2. Double-click `start.bat`. Alternatively: `py -m pip install -r requirements.txt` then `py afk_watcher.py`.
3. Your five previously supplied calibration screenshots are **already included** in `templates/`: `hud.png`, `knocked.png`, `ready.png`, `return.png`, `spectate.png`. Keep a fixed Fortnite resolution and HUD scale.
4. Configure the webhook below, then start with **F6**. Stop using **F7**, emergency stop **F8**.
5. **Upgrading from v5?** Keep your existing `config.json` and personal captures. Copy BOTH `afk_watcher.py` AND `mode_selector.py` plus all SIX new `templates/ui2026_*.png` into your existing folder. Simply copying the Python watcher file is no longer sufficient.

## Discord webhook setup

1. In your own Discord server: **Edit Channel → Integrations → Webhooks → New Webhook → Copy Webhook URL** (requires permission to manage webhooks).
2. Paste the full `https://discord.com/api/webhooks/...` URL into the masked **Webhook URL** field.
3. Press **Test**. Check Discord for `Fortnite AFK Watcher: Test notification` and check the status in the app.
4. Leave **Enable**, **Notify when returning to lobby**, and **Notify Pirate Shop Access** checked as needed. Settings save when you press Start or Test.
5. **Do not share your webhook URL:** it authorizes sending messages to your channel. The URL is saved in local plaintext `config.json`; treat that file as private.

### Automated messages

- On a confirmed *Return to Lobby* button click (not server-confirmed game completion): `✅ Game successfully completed... Heading back to lobby...`
- When *Pirate Shop Access* banner is detected over gameplay: `🏴‍☠️ Pirate Shop Access Obtained!`

No messages are sent if the webhook is empty or disabled. Notifications are asynchronous and should not delay input automation. The Pirate banner has to appear on the monitored game screen; the tool cannot inspect rewards from your account or detect them after the banner disappears. It debounces detections and only rearms after the banner has been absent for at least 10 seconds.

## Pirate Shop Access detection

Two cropped `pirate_sample_*.png` templates extracted from your uploaded screenshots are bundled. The watcher searches for them **independently of the current HUD stage**, at several scales. Since these screenshots came from other players, different resolutions/UI scaling could reduce accuracy. You can capture a better template from your own game using **Capture** beside **PIRATE SHOP ACCESS banner**. Capturing creates `templates/pirate.png` and adds it to the supplied samples. A template should include the distinctive text `YOU FOUND / PIRATE SHOP ACCESS`, not the whole screen.

Adjust **Pirate template match** if detection is too strict or too loose (default `0.72`). Lower values can cause false alerts. The watcher cannot guarantee 100% accurate recognition.

## Movement

Movement now defaults to **25–45 seconds per continuous walking leg** (adjustable in the GUI from 0.2 to 120 seconds). Forward and forward-diagonal walking are favored over sideways/backwards movement. There is no intentional multi-second pause between legs. During a long leg, the tool keeps checking visual game state roughly every 0.45 seconds and can immediately release the keys on Return to Lobby, spectating, knocked, ready, loading/queue, custom mode or survey screens. Screenshot matching still has some latency.

**Camera rotation (v5):** The earlier 480-unit default was too weak for some sensitivity setups and split into tiny 15-unit steps. v5 sends **4,800 relative mouse units for a nominal 90° turn** (9,600 for 180°) using larger ~200-unit packets, with no extra PyDirectInput pause. It also converts old v4 camera settings once, even if you keep your existing `config.json`. These are **mouse units, not guaranteed degrees**, and 4,800 could turn much more or much less than 90° on your setup. **Test before leaving the watcher running:** stop the watcher with F7; enter a turn strength between 200 and 30000; click **Test 90°**; switch focus to Fortnite within 3 seconds; see how far the camera actually turns. Example: if a 4,800-unit test visibly turns around 30°, try roughly 14,400; if it turns around 180°, try roughly 2,400. Then test again. Changes persist when you use the test button or Start. Fortnite could ignore injected relative mouse input entirely; if so, changing the number won't fix that, and no exact 90°/180° rotation is promised.

**Random emotes:** Enabled by default every **50–100 seconds during confirmed alive/storm gameplay**. The watcher releases movement keys, holds **U for 1–2 seconds**, presses a random digit **1–8** while U remains held, then releases U, and waits **3–4 seconds** without moving, clicking, jumping or turning before resuming. These waits are interruptible on game-state changes or F7/F8. You can turn off emotes or adjust their frequency in the GUI. Ensure your Fortnite bindings use U for the emote menu and 1–8 for the emote slots; if your game maps those digits to weapons instead, disable this option.

**After spectating disappears:** If a confirmed spectate indicator vanishes for more than about 1.1 seconds without Return to Lobby or another recognized priority screen, the watcher **assumes a squad reboot may have happened** and walks for **18–28 seconds** while checking for Return to Lobby, knocked and spectating indicators. This is only a heuristic; the game does not provide a verified reboot signal. If the alive HUD reappears, it resumes normal movement. If no alive HUD appears after that recovery window, it stops movement rather than wandering indefinitely on an unknown screen. The **Return to Lobby button always overrides** this temporary walking state. The game must remain focused.

If upgrading and your local `config.json` contained the previous exact default hold settings 2.0–4.0 seconds, the watcher automatically changes those defaults to 25.0–45.0 seconds. Custom durations are preserved.

## Note on messages

The “Game successfully completed” message follows your requested wording, but is triggered when the watcher detects and clicks **Return to Lobby**; it does not verify that matchmaking finished or that Fortnite awarded anything. Pirate Shop Access is also **screen recognition only**, not an account inventory verification.

## Deploy / Gliding detection

The watcher now has a **DEPLOY / GLIDING prompt** Capture button. While Fortnite displays the captured prompt, the app switches to **GLIDING / HOLDING W ONLY**. It holds W continuously and disables Space jumping, random A/S/D movement, mouse movement, and automatic attacks. It releases W when the prompt has been absent from two consecutive scans or when a higher-priority game screen appears.

Capture a small, distinctive portion of the **Deploy ...** prompt while you are falling/gliding in your own game. Use the same resolution and HUD scale as when running the watcher. Avoid capturing scenery behind the prompt. Without `templates/glide.png`, the tool cannot identify this stage and normal behaviour is unchanged. It checks the prompt periodically even during longer WASD holds, but recognition is not instantaneous and may miss prompts if the image changes.

The mouse click toggle still applies only during normal alive gameplay. The gliding stage overrides it. Reuse your existing `templates` folder if upgrading.

## SPACE TO DEPLOY mode

The included `templates/glide.png` is cropped from your provided Fortnite screenshot and contains the words `Space TO DEPLOY`. The watcher compares bright lettering instead of the changing transparent background. You can recapture the text if you change resolution, font scaling, or HUD layout.

- While the prompt is visible: hold W continuously, with no Space jumping, left-clicks, A/S/D, or camera changes.
- After two successive checks without the prompt: release continuous W and resume standard WASD, jumps, clicks, and camera movements.
- Normal gameplay detection still requires the alive HUD template to match. Return/Lobby/Knocked/Spectating states take priority.
- If the text cannot be detected because of unusual background or UI changes, movement may resume prematurely. Test while watching the display.

## Fortnite survey SKIP

When the Fortnite feedback survey appears, the watcher checks both the survey heading and SKIP button, then clicks SKIP after two consecutive detections. This takes priority over movement and lobby actions. The included screenshot templates are calibrated for the supplied survey screenshot. If Fortnite changes its layout, recapture the survey SKIP button and update `templates/survey_title.png` to match the new heading. Test in a supervised session first.

## Storm detection

Storm detection uses purple coverage across the gameplay area, not the changing green health bar. Two consecutive scans at >=72% purple coverage select STORM movement unless a higher-priority screen is found. The watcher also uses an included storm-knocked crop and a relaxed grayscale knocked indicator check, to stop moving when knocked. This is a visual heuristic, not a reliable health/game-state signal; supervise testing, because purple scenes and changed HUD layouts can produce mistakes. Storm detection only continues the existing movement pattern; it cannot navigate to safety.

## Discord action webhooks

Alongside Return to Lobby and Pirate Shop Access, the watcher can notify on game-state transitions and its automation actions. Enable **Notify game stage changes** and **Notify all actions (batched)**. Stage changes, SKIP, Ready, Return, glide transitions and other discrete actions are posted separately with cooldowns. Repeated WASD movements, camera adjustments and regular attack clicks are aggregated into a Discord summary every 15-300 seconds (default 30). This is intentional to avoid Discord rate-limit failures and high message volume. Notifications reflect watcher detection/actions, not guaranteed server-side game events.

Use the **Test** button to check that the Discord webhook URL accepts messages. For security, keep the URL private.

## Storm detection correction

Storm detection uses the purple tint across the central gameplay image, not screenshots of a username, player or health bar. Two consecutive frames with at least 72% purple coverage trigger the `IN STORM / CONTINUING MOVEMENT` stage. It does not need a storm screenshot. The previous `storm_knocked.png` example has been removed.

Knocked down is a distinct state: the configured `knocked.png` is checked separately, and matching that template takes priority over the purple storm tint. Because the knocked indicator itself may change under the storm tint, detection is not guaranteed. Never assume the purple tint means you're still alive. If that indicator fails in live play, recapture your own knocked indicator in storm conditions.

## Sequential webhooks and match duration

Discord notifications go through a single FIFO sending queue. They are transmitted one at a time, with a short spacing delay and retries for Discord rate limits. Movement/click updates remain batched according to the existing interval.

The match timer begins when the watcher clicks PLAY/READY and stops when it clicks RETURN TO LOBBY. The end-of-match webhook includes the elapsed time as MM:SS or HH:MM:SS. It includes lobby and queue time by design. If the watcher was started after PLAY, the duration is marked unavailable. The tracker measures the watcher's button actions, not server-confirmed match start or completion. Notifications can be delayed by webhook rate limits or network errors.

## Custom game menu recovery

If both CUSTOM KEY and GO TO LOBBY are detected on the bottom of the custom mode details screen, the watcher sends no clicks or movement and scrolls up every 0.35 seconds. It always scrolls for at least 10 seconds. After that, it requires two consecutive confirmations of both the Battle Royale starter title and yellow PLAY button before resuming normal lobby automation. If confirmation is missing after 65 seconds, the watcher stops instead of clicking the wrong screen.

The included templates use the supplied screenshots at 1920x1080. If your Fortnite UI layout or resolution changes, recapture CUSTOM KEY, GO TO LOBBY and the BATTLE ROYALE title using their Capture buttons. The BATTLE ROYALE starter title should be cropped without including the PLAY button. If the game has a survey on top of that screen, handle it before initiating menu recovery.

## Squad Fill auto-correction

**v6 replaces the broken mode-setup screenshots.** In v5, `settings_ranked.png` and `settings_team.png` were actually unrelated fragments of the lobby background, so they could never reliably prove the settings menu was open. v6 removes these two unusable images. Six `templates/ui2026_*.png` files are now cropped directly from the mode-settings screenshot you supplied (Ranked, OFF, Team Size, SQUAD, Team Fill). The program uses a new `mode_selector.py` recogniser to match three independent menu labels at different UI sizes, then inspect the yellow selected-state indicators.

On each return to a ready lobby, the program opens the mode options, verifies and—if necessary—corrects **Build or Zero Build (your preferred choice), Ranked OFF, Squad, Fill**, one option at a time. It only clicks values that are not yet selected. It verifies all four settings twice, closes the picker (ESC, or captured CLOSE if provided), then waits for the lobby PLAY screen. PLAY remains blocked if the menu cannot be recognised, it refuses to close, the values remain incorrect, or the lobby label contradicts the menu. It does not blindly click percentages of the entire screen.

**Optional captures for extra reliability:** `Mode selector ABOVE the lobby PLAY button` (`mode_picker.png`) tells the bot exactly where to click to open the picker. Crop ONLY that distinctive clickable label in the normal Fortnite lobby—not the big yellow PLAY button. `CLOSE button at bottom of the Battle Royale options panel` (`mode_close.png`) tells the bot where to click CLOSE; without it, the watcher tries ESC. If you do not capture these, the watcher tries its existing lobby Build/Zero Build label templates, or an estimate just above the recognised PLAY button. If the menu does not open, it stops instead of repeatedly pressing Play or random controls.

**Calibration note:** The provided picture is a crop, not an actual full-screen game screenshot. Matching the real UI and its selected-state highlights is tested offline at several simulated sizes and positions, but opening/closing the picker and choosing the proper button in your actual Fortnite window must still be tested with the game visible. If that part fails, capture `mode_picker` and `mode_close`. Keep your usual Windows display scaling, game resolution and Fortnite HUD scale while testing.

## Discord alert when screen is unknown for 20 minutes

Paste your Discord webhook in **Webhook URL**, then paste your numeric Discord **User ID** in the new field and check **Ping after 20 minutes on an unknown screen**. To copy your Discord User ID, turn on Discord Developer Mode (User Settings → Advanced), then right-click your user profile and select **Copy User ID**. Do not enter your username or @handle.

When the watcher continuously reports **WAITING / UNKNOWN SCREEN** for 20 minutes, it sends one queued Discord message mentioning `<@your_id>` and requesting manual attention. The timer resets on any other recognised stage, loss of Fortnite focus, or stopping the watcher. A new 20-minute unknown-screen period can trigger another notification. The existing webhook setting must be enabled and valid. Discord notification permissions may control whether you receive a push alert.

The timer counts while the watcher is running and Fortnite is focused; it will not send alerts during a recognised game state, including storm, matchmaking, or lobby. Test the integration with your webhook's Test button first.

## v4: Fast turns, immediate post-glide sprint

- The 90° and 180° turns are approximately **10x faster** than in v3, while
  preserving the configured number of mouse movement units for each angle.
- Once **SPACE TO DEPLOY** disappears twice, the watcher immediately presses
  **W + Left Ctrl**. It continues moving during a short HUD-detection grace
  window, unless Return to Lobby / spectating / other higher-priority UI
  takes over.
- Normal WASD movement also holds **Left Ctrl**. Fortnite keybinds differ;
  if you have Left Ctrl configured for crouch, rebind it to Sprint.
- To keep your saved captures and Discord settings, copy only `afk_watcher.py`
  into your existing folder, rather than overwriting the templates and config.
- The camera is still approximate and requires your own sensitivity setting.
  Try this with supervision first; game behavior isn't covered by tests.

## v5: Stronger camera turns and 90° calibration (10 Nov 2026)

- Default turn distance increased 10x (480 → 4800 relative mouse units for the target 90° turn); 180° uses twice that distance.
- Send larger relative mouse movement packets quickly, rather than 15-unit microsteps; avoid extra per-input delay.
- New **Test 90°** button: stop the watcher, click the button, focus Fortnite within 3 seconds, and watch how far the test turns. Adjust the value (200–30000) as needed.
- An existing v4 config.json is migrated once, preserving webhook IDs, input templates and your other settings.
- There is still no reliable screen-to-degree measurement, and synthetic mouse inputs may be filtered by a game.

## V8 — Treasure Found auto-claim (always enabled)

If the reward screen contains both **TREASURE FOUND!** and **CLAIM ALL**, the
watcher stops movement, confirms the two text labels across distinct scans,
clicks the actual detected **CLAIM ALL** button, and sends a Discord webhook
message. It uses your existing Discord webhook and mentions your Discord User
ID if filled in. It does not add an additional option or change other settings.
The handler retries a maximum of three times; if the button remains visible,
it alerts you and stops rather than continuing to click blindly.

To update an existing installation, copy `afk_watcher.py`,
`treasure_detector.py`, and `templates/treasure_title_mask.png` plus
`templates/treasure_claim_mask.png`; keep your `config.json` and existing
captured templates.

## v11: Knocked, unknown and reboot movement

- Knocked (DBNO): small crawling movements with W/A/S/D; no sprint or jumping.
- Unknown screen *after confirmed gameplay*: W/A/S/D for 1.8–2.6 seconds,
  resting 1.8–3.0 seconds between; unknown lobby/menu does not trigger movement.
- Spectating disappeared: sideways movement (A or D) for up to 10 seconds,
  stopping sooner if normal HUD or a higher-priority screen appears.
- Return to Lobby, menu, loading, treasure, lost focus and manual stop override movement.
- Set `WASD + Left Ctrl sprint + jump + camera` ON to enable movement routines.
